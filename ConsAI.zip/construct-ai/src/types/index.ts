export type ConstructionType =
  | '🏠 House'
  | '🏥 Hospital'
  | '🏫 Engineering College'
  | '🚒 Fire Station'
  | '🏢 Apartment'
  | '🏭 Commercial Building'
  | '🏬 Shopping Complex'
  | '🏛️ Government Building'
  | '➕ Other';

export type DeviationStatus = 'ON_TRACK' | 'AT_RISK' | 'SIGNIFICANT_DELAY';
export type ProjectStatus = 'ON_TRACK' | 'AT_RISK' | 'DELAYED' | 'COMPLETED';
export type TaskStatus = 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
export type RecoveryStatus = 'RECOMMENDED' | 'APPROVED' | 'REJECTED';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  createdAt: string;
}

export interface Task {
  id: string;
  name: string;
  startDay: number;
  endDay: number;
  expectedProgress: number; // percentage (0-100)
  expectedWorkers: number;
  expectedWorkingHours: number;
  notes?: string;
  status: TaskStatus;
}

export interface DailyEntry {
  id: string;
  blockId: string;
  dayNumber: number;
  date: string;
  taskId: string;
  taskName: string;
  plannedProgress: number; // % expected on this day
  actualProgress: number;  // % manually entered by engineer
  workersPresent: number;
  actualWorkingHours: number;
  materialsUsed: string;   // e.g. "Cement: 50 Bags\nSteel: 200 kg\nConcrete: 5 m³"
  problems: string;        // e.g. "Rainfall", "Material Delay", etc.
  weather: string;         // e.g. "Sunny", "Rain", "Cloudy", "High Temperature", "Other"
  engineerDiary: string;   // Large continuous text written by the engineer
  status: DeviationStatus;
  submittedAt: string;
}

export interface Block {
  id: string;
  name: string;             // e.g. "Block A"
  engineerName: string;     // e.g. "Ravi"
  engineerEmail?: string;
  initialWorkers: number;   // e.g. 20
  currentWorkers: number;   // Active count after adjustments
  plannedWorkingHours: number; // e.g. 7
  currentWorkingHours: number; // Active hours after adjustments
  tasks: Task[];
  dailyEntries: DailyEntry[];
  currentProgress: number;  // Latest actual progress (0-100)
}

export interface ReallocationRecommendation {
  fromBlockId: string;
  fromBlockName: string;
  toBlockId: string;
  toBlockName: string;
  workersToReallocate: number;
  rationale: string;
  sourceBlockStatus: DeviationStatus;
  sourceBlockSurplus: number;
}

export interface AIRecoveryAnalysis {
  id: string;
  projectId: string;
  blockId: string;
  blockName: string;
  triggerDay: number;
  estimatedDelayDays: number;
  progressGap: number;
  currentWorkers: number;
  recommendedWorkers: number;
  extraWorkers: number;
  currentHours: number;
  recommendedHours: number;
  extraHours: number;
  reallocationOpportunity: ReallocationRecommendation | null;
  recoveryMilestoneReviewDays: number; // e.g. 2
  aiRationale: string;
  status: RecoveryStatus;
  createdAt: string;
  disclaimer: string;
  approvedAt?: string;
}

export interface Project {
  id: string;
  name: string;
  location: string;
  type: ConstructionType | string;
  durationDays: number;
  startDate: string;
  currentDay: number;
  status: ProjectStatus;
  completedAt: string | null;
  blocks: Block[];
  recoveryLogs: AIRecoveryAnalysis[];
  createdAt: string;
}

export type RoleType = 'MAIN_ENGINEER' | 'BLOCK_ENGINEER';

export interface ActiveRole {
  type: RoleType;
  blockId?: string;       // defined when type === 'BLOCK_ENGINEER'
  engineerName?: string;  // e.g. "Ravi"
  blockName?: string;     // e.g. "Block A"
}

export interface ScheduleDeviation {
  gapPercent: number;
  plannedProgress: number;
  actualProgress: number;
  estimatedDelayDays: number;
  status: DeviationStatus;
  isSignificant: boolean; // true if estimatedDelayDays > 3
  dailyRate: number;
  remainingDays: number;
}
