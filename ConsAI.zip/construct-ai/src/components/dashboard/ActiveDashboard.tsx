import React from 'react';
import {
  FolderGit2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  HardHat,
  MapPin,
  Calendar,
  Layers,
  ArrowRight,
  PlusCircle,
  Bot,
  Users,
  FileSpreadsheet,
  BookOpenCheck,
  LineChart,
  Sparkles,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import {
  analyzeBlockDeviation,
  calculateProjectOverview,
} from '../../services/deviationEngine';

interface ActiveDashboardProps {
  onNavigate: (view: string) => void;
  onOpenAIRecovery: (blockId?: string) => void;
  onOpenDailyEntry: (blockId?: string) => void;
}

export const ActiveDashboard: React.FC<ActiveDashboardProps> = ({
  onNavigate,
  onOpenAIRecovery,
  onOpenDailyEntry,
}) => {
  const { projects, activeProject, selectProject, activeRole } = useProject();

  if (!activeProject) {
    return null;
  }

  const activeProjectsList = projects.filter(p => p.status !== 'COMPLETED');
  const completedProjectsList = projects.filter(p => p.status === 'COMPLETED');

  const onTrackCount = projects.filter(p => p.status === 'ON_TRACK').length;
  const atRiskCount = projects.filter(p => p.status === 'AT_RISK').length;
  const delayedCount = projects.filter(p => p.status === 'DELAYED').length;

  const overview = calculateProjectOverview(activeProject);

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top 4 Summary Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400">Active Projects</p>
            <h3 className="text-2xl font-black text-white mt-1">{activeProjectsList.length}</h3>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center">
            <FolderGit2 className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400">Projects On Track</p>
            <h3 className="text-2xl font-black text-emerald-400 mt-1">{onTrackCount}</h3>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400">Projects At Risk / Delayed</p>
            <h3 className="text-2xl font-black text-amber-400 mt-1">{atRiskCount + delayedCount}</h3>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-400">Completed Projects</p>
            <h3 className="text-2xl font-black text-indigo-400 mt-1">{completedProjectsList.length}</h3>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Significant Delay Alert Banner (Triggered when any block deviation > 3 days) */}
      {overview.hasSignificantDelay && (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-rose-950/80 via-slate-900 to-slate-900 border border-rose-500/40 shadow-xl shadow-rose-500/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
              <AlertTriangle className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded bg-rose-500 text-white">
                  3-Day Rule Exceeded
                </span>
                <h3 className="text-base font-bold text-white">
                  Significant Schedule Deviation Detected
                </h3>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                One or more construction blocks have accumulated over 3 days of estimated delay. The AI-Assisted Recovery Assistant is unlocked to analyze site logs and generate a recovery simulation.
              </p>
            </div>
          </div>
          <button
            onClick={() => onOpenAIRecovery()}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center gap-2 shrink-0 transition transform active:scale-95"
          >
            <Bot className="w-4 h-4" />
            <span>Ask AI Recovery Assistant</span>
          </button>
        </div>
      )}

      {/* Active Project Hero Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="text-lg font-bold">{activeProject.type}</span>
              <h2 className="text-2xl font-black text-white tracking-tight">
                {activeProject.name}
              </h2>
              {/* Status Badge */}
              <span
                className={`text-xs font-extrabold uppercase px-2.5 py-1 rounded-full border ${
                  activeProject.status === 'COMPLETED'
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : activeProject.status === 'DELAYED'
                    ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                    : activeProject.status === 'AT_RISK'
                    ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                    : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                }`}
              >
                {activeProject.status === 'COMPLETED'
                  ? '✅ Completed'
                  : activeProject.status === 'DELAYED'
                  ? '🔴 Significant Delay'
                  : activeProject.status === 'AT_RISK'
                  ? '🟡 At Risk'
                  : '🟢 On Track'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-400" />
                {activeProject.location}
              </span>
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                {activeProject.blocks.length} Construction Blocks
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                Planned Duration: {activeProject.durationDays} Days (Current Day: {activeProject.currentDay})
              </span>
            </div>
          </div>

          {/* Quick CTAs */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenDailyEntry()}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-2 transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add Daily Entry</span>
            </button>
            <button
              onClick={() => onNavigate('plans')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 flex items-center gap-2 transition"
            >
              <FileSpreadsheet className="w-4 h-4 text-slate-400" />
              <span>View Plan</span>
            </button>
          </div>
        </div>

        {/* Overall Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300 flex items-center gap-2">
              Overall Project Progress
              <span className="text-slate-400 font-normal">
                (Planned: {overview.plannedProgress}%)
              </span>
            </span>
            <span className="font-mono font-bold text-amber-400 text-sm">
              {overview.overallProgress}% Completed
            </span>
          </div>

          <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800 flex">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                overview.overallProgress >= 100
                  ? 'bg-emerald-500'
                  : overview.hasSignificantDelay
                  ? 'bg-rose-500'
                  : 'bg-gradient-to-r from-amber-500 to-yellow-400'
              }`}
              style={{ width: `${Math.min(100, overview.overallProgress)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Construction Blocks Status Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            Block Status & Daily Submissions
          </h3>
          <span className="text-xs text-slate-400">
            Current Day: <strong className="text-white">Day {activeProject.currentDay}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {activeProject.blocks.map(block => {
            const dev = analyzeBlockDeviation(block, activeProject);
            const hasSubmittedToday = (block.dailyEntries || []).some(
              e => e.dayNumber === activeProject.currentDay
            );
            const latestEntry = (block.dailyEntries || [])[block.dailyEntries.length - 1];

            const isAllowedRole =
              activeRole.type === 'MAIN_ENGINEER' || activeRole.blockId === block.id;

            return (
              <div
                key={block.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 hover:border-slate-700 transition"
              >
                {/* Block Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-white text-base">{block.name}</h4>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          dev.status === 'SIGNIFICANT_DELAY'
                            ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                            : dev.status === 'AT_RISK'
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                        }`}
                      >
                        {dev.status === 'SIGNIFICANT_DELAY'
                          ? '🔴 >3d Delay'
                          : dev.status === 'AT_RISK'
                          ? '🟡 At Risk'
                          : '🟢 On Track'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                      <HardHat className="w-3.5 h-3.5 text-slate-400" />
                      Assigned: <strong className="text-slate-200">{block.engineerName}</strong>
                    </p>
                  </div>

                  {/* Submission Status for Current Day */}
                  <div
                    className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5 ${
                      hasSubmittedToday
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/30 animate-pulse'
                    }`}
                  >
                    {hasSubmittedToday ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Submitted</span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-3.5 h-3.5" />
                        <span>Pending</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Progress Comparison */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span>Actual Progress:</span>
                    <span className="font-bold text-white">{dev.actualProgress}%</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Planned Progress:</span>
                    <span>{dev.plannedProgress}%</span>
                  </div>
                  {dev.gapPercent > 0 && (
                    <div className="flex justify-between text-rose-400 text-[11px] font-semibold">
                      <span>Schedule Gap:</span>
                      <span>-{dev.gapPercent}% (~{dev.estimatedDelayDays} days behind)</span>
                    </div>
                  )}

                  {/* Micro Progress Bar */}
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full ${
                        dev.status === 'SIGNIFICANT_DELAY'
                          ? 'bg-rose-500'
                          : dev.status === 'AT_RISK'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, dev.actualProgress)}%` }}
                    />
                  </div>
                </div>

                {/* Resource Metrics */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                  <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                    <span className="block text-[10px] uppercase font-bold text-slate-400">Workers</span>
                    <span className="font-bold text-white text-sm">
                      {block.currentWorkers || block.initialWorkers}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                    <span className="block text-[10px] uppercase font-bold text-slate-400">Shift</span>
                    <span className="font-bold text-white text-sm">
                      {block.currentWorkingHours || block.plannedWorkingHours} hrs/d
                    </span>
                  </div>
                </div>

                {/* Latest Diary Snippet */}
                {latestEntry?.engineerDiary && (
                  <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 text-[11px] text-slate-300">
                    <p className="text-[10px] font-bold uppercase text-amber-400/90 mb-0.5">
                      Day {latestEntry.dayNumber} Diary:
                    </p>
                    <p className="italic line-clamp-2 text-slate-400">
                      "{latestEntry.engineerDiary}"
                    </p>
                  </div>
                )}

                {/* Actions per block */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => onOpenDailyEntry(block.id)}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                  >
                    <span>{hasSubmittedToday ? 'Update Entry' : '+ Add Entry'}</span>
                  </button>

                  {dev.status === 'SIGNIFICANT_DELAY' && (
                    <button
                      onClick={() => onOpenAIRecovery(block.id)}
                      className="py-2 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-1 transition"
                      title="Run AI Recovery Simulation"
                    >
                      <Bot className="w-3.5 h-3.5 text-rose-400" />
                      <span>AI Assist</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
