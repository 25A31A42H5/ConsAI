import React from 'react';
import { PlusCircle, HardHat, FileText, CheckSquare, Sparkles, ArrowRight } from 'lucide-react';

interface EmptyDashboardProps {
  onCreateProject: () => void;
}

export const EmptyDashboard: React.FC<EmptyDashboardProps> = ({ onCreateProject }) => {
  return (
    <div className="flex-1 p-6 lg:p-10 max-w-5xl mx-auto flex flex-col justify-center items-center text-center">
      {/* Empty State Hero Container */}
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl p-8 lg:p-12 shadow-2xl space-y-8 relative overflow-hidden">
        {/* Subtle Background Accent */}
        <div className="absolute -top-20 -right-20 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Big Construction Icon */}
        <div className="w-20 h-20 rounded-3xl bg-amber-500/15 border border-amber-500/30 mx-auto flex items-center justify-center text-amber-400 shadow-xl shadow-amber-500/10">
          <HardHat className="w-10 h-10" />
        </div>

        {/* Main Empty Message */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-300">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            Prototype Ready
          </div>
          <h2 className="text-2xl lg:text-3xl font-black text-white tracking-tight">
            No projects created yet.
          </h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            ConstructAI starts with zero preloaded fake data. As the Main Engineer, create your first project and define construction blocks manually.
          </p>
        </div>

        {/* Primary CTA Button */}
        <div>
          <button
            onClick={onCreateProject}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-base shadow-xl shadow-amber-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <PlusCircle className="w-5 h-5" />
            <span>Create New Project</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* 3-Step Preview of Manual Workflow */}
        <div className="pt-6 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              Step 1
            </div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <HardHat className="w-3.5 h-3.5 text-slate-400" />
              Project & Blocks
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Enter location, type, planned duration, blocks, and assign engineers.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              Step 2
            </div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              Plan Tasks
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Main Engineer manually creates tasks, start/end days, and targets.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              Step 3
            </div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <CheckSquare className="w-3.5 h-3.5 text-slate-400" />
              Daily Entries & AI
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Enter daily progress and engineer diaries; AI assists on delays &gt;3 days.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
