import React from 'react';
import {
  CheckCircle2,
  FolderGit2,
  Calendar,
  MapPin,
  Layers,
  Award,
  ArrowRight,
  BookOpen,
  Bot,
  Sparkles,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

interface CompletedProjectsProps {
  onOpenProject: (projectId: string) => void;
}

export const CompletedProjects: React.FC<CompletedProjectsProps> = ({ onOpenProject }) => {
  const { projects } = useProject();

  const completedList = projects.filter(p => p.status === 'COMPLETED');

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              Completed Construction Projects Archive
            </h2>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              Permanent Archive
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Historical records, original plans, full engineer diaries, and AI recovery logs are permanently preserved.
          </p>
        </div>

        <div className="px-4 py-2 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
          Total Completed: <strong className="text-emerald-400 font-bold">{completedList.length}</strong>
        </div>
      </div>

      {completedList.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <Award className="w-12 h-12 text-slate-600 mx-auto" />
          <h4 className="text-base font-bold text-white">No Completed Projects Yet</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            When all blocks in an active project reach 100% progress and milestones are fulfilled, the project automatically transitions into this permanent historical archive.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {completedList.map(project => {
            const totalEntries = project.blocks.reduce(
              (acc, b) => acc + (b.dailyEntries?.length || 0),
              0
            );

            return (
              <div
                key={project.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 hover:border-emerald-500/40 transition"
              >
                {/* Project Header */}
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-400">{project.type}</span>
                    <h3 className="text-lg font-black text-white">{project.name}</h3>
                    <p className="text-xs text-slate-400 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-400" />
                      {project.location}
                    </p>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-black uppercase">
                    100% Completed
                  </span>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Duration</span>
                    <span className="font-bold text-white">{project.durationDays} Days</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Blocks</span>
                    <span className="font-bold text-white">{project.blocks.length} Blocks</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Diaries</span>
                    <span className="font-bold text-amber-400">{totalEntries} Entries</span>
                  </div>
                </div>

                {/* Blocks Breakdown */}
                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                  <span className="text-[11px] font-bold text-slate-300 block">
                    Completed Blocks:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {project.blocks.map(b => (
                      <span
                        key={b.id}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 font-medium"
                      >
                        {b.name} ({b.engineerName})
                      </span>
                    ))}
                  </div>
                </div>

                {/* Footer Actions */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Finished: {project.completedAt ? new Date(project.completedAt).toLocaleDateString() : 'Recorded'}
                  </span>
                  <button
                    onClick={() => onOpenProject(project.id)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition"
                  >
                    <span>Open Historical Record</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
