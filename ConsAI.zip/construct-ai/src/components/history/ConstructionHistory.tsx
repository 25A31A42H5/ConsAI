import React, { useState } from 'react';
import {
  BookOpen,
  Calendar,
  Layers,
  Clock,
  Users,
  AlertTriangle,
  CloudRain,
  Package,
  CheckCircle2,
  Filter,
  Search,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const ConstructionHistory: React.FC = () => {
  const { activeProject } = useProject();
  const [selectedBlockId, setSelectedBlockId] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!activeProject) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project selected.
      </div>
    );
  }

  // Aggregate all daily entries
  const allEntries: Array<{
    blockName: string;
    engineerName: string;
    entry: any;
  }> = [];

  activeProject.blocks.forEach(block => {
    (block.dailyEntries || []).forEach(entry => {
      allEntries.push({
        blockName: block.name,
        engineerName: block.engineerName,
        entry,
      });
    });
  });

  // Filter entries
  const filteredEntries = allEntries
    .filter(item => {
      if (selectedBlockId !== 'ALL' && item.entry.blockId !== selectedBlockId) {
        return false;
      }
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          item.entry.engineerDiary.toLowerCase().includes(query) ||
          item.entry.taskName.toLowerCase().includes(query) ||
          item.entry.problems.toLowerCase().includes(query) ||
          item.blockName.toLowerCase().includes(query) ||
          item.engineerName.toLowerCase().includes(query)
        );
      }
      return true;
    })
    .sort((a, b) => b.entry.dayNumber - a.entry.dayNumber);

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              Construction History & Site Diaries
            </h2>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Permanent Record
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Complete chronological record of all daily construction entries, diaries, materials, and site constraints.
          </p>
        </div>

        {/* Filter & Search */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-56">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search diaries, tasks, issues..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={selectedBlockId}
            onChange={e => setSelectedBlockId(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500"
          >
            <option value="ALL">All Construction Blocks</option>
            {activeProject.blocks.map(b => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.engineerName})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Entries List */}
      {filteredEntries.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <BookOpen className="w-12 h-12 text-slate-600 mx-auto" />
          <h4 className="text-base font-bold text-white">No Construction Entries Found</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Daily entries submitted by Block Engineers will be preserved here permanently with their full diaries and material logs.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredEntries.map(({ blockName, engineerName, entry }) => (
            <div
              key={entry.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md space-y-4 hover:border-slate-700 transition"
            >
              {/* Entry Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-amber-500/15 text-amber-400 border border-amber-500/30 font-black text-xs rounded-xl">
                    Day {entry.dayNumber}
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{blockName}</span>
                      <span className="text-xs text-slate-400 font-normal">
                        (Eng. {engineerName})
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Task: <strong className="text-slate-200">{entry.taskName}</strong> • Date: {entry.date}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Progress</span>
                    <span className="font-mono font-bold text-white">
                      Act: {entry.actualProgress}% <span className="text-slate-400">/ Plan: {entry.plannedProgress}%</span>
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      entry.status === 'SIGNIFICANT_DELAY'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                        : entry.status === 'AT_RISK'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    }`}
                  >
                    {entry.status === 'SIGNIFICANT_DELAY'
                      ? '🔴 Delayed'
                      : entry.status === 'AT_RISK'
                      ? '🟡 At Risk'
                      : '🟢 On Track'}
                  </span>
                </div>
              </div>

              {/* Resource & Condition Badges */}
              <div className="flex flex-wrap gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                  <Users className="w-3 h-3 text-blue-400" />
                  {entry.workersPresent} Workers Present
                </span>

                <span className="px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                  <Clock className="w-3 h-3 text-amber-400" />
                  {entry.actualWorkingHours} Working Hours
                </span>

                <span className="px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                  <CloudRain className="w-3 h-3 text-blue-400" />
                  {entry.weather}
                </span>

                {entry.problems && entry.problems !== 'None (Normal Operations)' && (
                  <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-center gap-1.5 font-semibold">
                    <AlertTriangle className="w-3 h-3 text-rose-400" />
                    Issue: {entry.problems}
                  </span>
                )}
              </div>

              {/* Materials */}
              {entry.materialsUsed && (
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs font-mono text-slate-300">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                    Materials Consumed:
                  </span>
                  <pre className="whitespace-pre-wrap font-sans text-xs">{entry.materialsUsed}</pre>
                </div>
              )}

              {/* Engineer Diary (Full text) */}
              <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-wider">
                  <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                  Engineer Diary Entry:
                </div>
                <p className="text-xs text-slate-200 italic leading-relaxed">
                  "{entry.engineerDiary}"
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
