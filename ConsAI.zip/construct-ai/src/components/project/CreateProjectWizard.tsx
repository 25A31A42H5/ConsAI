import React, { useState } from 'react';
import {
  HardHat,
  MapPin,
  Calendar,
  Layers,
  Users,
  Clock,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Building2,
  Sparkles,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { ConstructionType } from '../../types';

interface CreateProjectWizardProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const CONSTRUCTION_TYPES: Array<{ label: ConstructionType; icon: string }> = [
  { label: '🏠 House', icon: '🏠' },
  { label: '🏥 Hospital', icon: '🏥' },
  { label: '🏫 Engineering College', icon: '🏫' },
  { label: '🚒 Fire Station', icon: '🚒' },
  { label: '🏢 Apartment', icon: '🏢' },
  { label: '🏭 Commercial Building', icon: '🏭' },
  { label: '🏬 Shopping Complex', icon: '🏬' },
  { label: '🏛️ Government Building', icon: '🏛️' },
  { label: '➕ Other', icon: '➕' },
];

export const CreateProjectWizard: React.FC<CreateProjectWizardProps> = ({
  onSuccess,
  onCancel,
}) => {
  const { createProject } = useProject();

  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [selectedType, setSelectedType] = useState<string>('🏫 Engineering College');
  const [customType, setCustomType] = useState('');
  const [durationDays, setDurationDays] = useState<number>(30);
  const [startDate, setStartDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [blockCount, setBlockCount] = useState<number>(3);

  // Per-block configuration array
  const [blocksData, setBlocksData] = useState<
    Array<{
      name: string;
      engineerName: string;
      initialWorkers: number;
      plannedWorkingHours: number;
    }>
  >([
    { name: 'Block A', engineerName: 'Ravi', initialWorkers: 20, plannedWorkingHours: 7 },
    { name: 'Block B', engineerName: 'Suresh', initialWorkers: 25, plannedWorkingHours: 7 },
    { name: 'Block C', engineerName: 'Kiran', initialWorkers: 30, plannedWorkingHours: 7 },
  ]);

  const [error, setError] = useState('');

  // Synchronize block array when block count input changes
  const handleBlockCountChange = (count: number) => {
    const validCount = Math.max(1, Math.min(10, count || 1));
    setBlockCount(validCount);

    const newBlocks = Array.from({ length: validCount }, (_, i) => {
      const char = String.fromCharCode(65 + i);
      if (blocksData[i]) {
        return blocksData[i];
      }
      return {
        name: `Block ${char}`,
        engineerName: '',
        initialWorkers: 20,
        plannedWorkingHours: 7,
      };
    });
    setBlocksData(newBlocks);
  };

  const updateBlockField = (
    index: number,
    field: 'name' | 'engineerName' | 'initialWorkers' | 'plannedWorkingHours',
    val: any
  ) => {
    const updated = [...blocksData];
    updated[index] = { ...updated[index], [field]: val };
    setBlocksData(updated);
  };

  const handleNext = () => {
    setError('');
    if (step === 1) {
      if (!name.trim()) {
        setError('Please enter the project name.');
        return;
      }
      if (!location.trim()) {
        setError('Please enter the construction site location.');
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (selectedType === '➕ Other' && !customType.trim()) {
        setError('Please specify the custom construction type.');
        return;
      }
      setStep(3);
    } else if (step === 3) {
      if (!durationDays || durationDays <= 0) {
        setError('Please enter a valid planned project duration in days.');
        return;
      }
      if (!startDate) {
        setError('Please select a project start date.');
        return;
      }
      setStep(4);
    } else if (step === 4) {
      if (!blockCount || blockCount < 1) {
        setError('Please enter at least 1 construction block.');
        return;
      }
      setStep(5);
    } else if (step === 5) {
      // Validate block engineers
      const missingEngineer = blocksData.find(b => !b.engineerName.trim());
      if (missingEngineer) {
        setError(`Please enter the assigned engineer name for ${missingEngineer.name}.`);
        return;
      }

      // Create the project!
      const finalType = selectedType === '➕ Other' ? customType.trim() : selectedType;
      createProject(name, location, finalType, durationDays, startDate, blocksData);
      onSuccess();
    }
  };

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-4xl mx-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-10 shadow-2xl space-y-8">
        {/* Wizard Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-xl shadow-md shadow-amber-500/10">
              🏗️
            </div>
            <div>
              <h2 className="text-xl lg:text-2xl font-black text-white">
                Create New Construction Project
              </h2>
              <p className="text-xs text-slate-400">
                Step {step} of 5 — Manual Project Setup
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-lg hover:bg-slate-800 transition"
          >
            Cancel
          </button>
        </div>

        {/* Step Progress Indicators */}
        <div className="grid grid-cols-5 gap-2">
          {[
            'General Info',
            'Type',
            'Schedule',
            'Block Count',
            'Assign Engineers',
          ].map((title, i) => {
            const stepNum = i + 1;
            const isDone = step > stepNum;
            const isCurrent = step === stepNum;
            return (
              <div key={stepNum} className="space-y-1.5">
                <div
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    isDone
                      ? 'bg-emerald-500'
                      : isCurrent
                      ? 'bg-amber-500'
                      : 'bg-slate-800'
                  }`}
                />
                <p
                  className={`text-[10px] font-bold truncate hidden sm:block ${
                    isCurrent
                      ? 'text-amber-400'
                      : isDone
                      ? 'text-emerald-400'
                      : 'text-slate-400'
                  }`}
                >
                  {title}
                </p>
              </div>
            );
          })}
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium animate-in fade-in">
            {error}
          </div>
        )}

        {/* Step 1: Project Name & Location */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Project Identity & Location</h3>
              <p className="text-xs text-slate-400">
                Enter the official project title and physical site location.
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Project Name <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Surampalem Engineering College"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 transition placeholder:text-slate-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  Construction Location <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Surampalem, East Godavari District"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 transition placeholder:text-slate-600"
                />
                <p className="text-[11px] text-slate-400">
                  Manual text entry (No Maps API required).
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Type of Construction */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Type of Construction</h3>
              <p className="text-xs text-slate-400">
                Select the structural category for this construction site.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {CONSTRUCTION_TYPES.map(item => {
                const isSelected = selectedType === item.label;
                return (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => setSelectedType(item.label)}
                    className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between gap-3 ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500 shadow-md shadow-amber-500/10'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="text-2xl">{item.icon}</span>
                    <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {selectedType === '➕ Other' && (
              <div className="space-y-1.5 pt-2">
                <label className="text-xs font-semibold text-slate-300">
                  Specify Custom Construction Type
                </label>
                <input
                  type="text"
                  value={customType}
                  onChange={e => setCustomType(e.target.value)}
                  placeholder="e.g. Railway Bridge, Airport Terminal"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 transition"
                />
              </div>
            )}
          </div>
        )}

        {/* Step 3: Planned Duration & Start Date */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Planned Project Duration</h3>
              <p className="text-xs text-slate-400">
                How many days are planned to complete this project?
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Planned Duration (Days) <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max="1000"
                  value={durationDays}
                  onChange={e => setDurationDays(parseInt(e.target.value) || 0)}
                  placeholder="e.g. 30, 365"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-amber-500 transition"
                />
                <p className="text-[11px] text-slate-400">
                  e.g., 30 Days for prototype testing, or 365 Days for full year.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                  Start Date <span className="text-amber-400">*</span>
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 transition"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Number of Blocks */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Number of Construction Blocks</h3>
              <p className="text-xs text-slate-400">
                How many construction blocks does this project have?
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-amber-400" />
                  Number of Blocks (1 to 10) <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={blockCount}
                  onChange={e => handleBlockCountChange(parseInt(e.target.value) || 1)}
                  placeholder="3"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-700 text-white text-base font-black focus:outline-none focus:border-amber-500 transition"
                />
              </div>

              {/* Quick Select Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-xs text-slate-400">Quick set:</span>
                {[1, 2, 3, 4, 5].map(num => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleBlockCountChange(num)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border transition ${
                      blockCount === num
                        ? 'bg-amber-500 text-slate-950 border-amber-500'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {num} {num === 1 ? 'Block' : 'Blocks'}
                  </button>
                ))}
              </div>

              {/* Preview of block placeholders */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <p className="text-xs font-semibold text-slate-300">
                  Blocks to be created ({blockCount}):
                </p>
                <div className="flex flex-wrap gap-2">
                  {blocksData.map((b, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-slate-800 text-amber-400 border border-slate-700 text-xs font-bold"
                    >
                      {b.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Assign Engineers, Workers & Working Hours per Block */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">
                Block Engineers & Workforce Setup
              </h3>
              <p className="text-xs text-slate-400">
                Assign engineers, initial worker headcount, and planned daily working hours for each block.
              </p>
            </div>

            <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
              {blocksData.map((block, index) => (
                <div
                  key={index}
                  className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                    <span className="font-extrabold text-amber-400 text-sm flex items-center gap-2">
                      <Layers className="w-4 h-4" />
                      {block.name}
                    </span>
                    <span className="text-[11px] text-slate-400">Block #{index + 1}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-300">
                        Block Name
                      </label>
                      <input
                        type="text"
                        value={block.name}
                        onChange={e => updateBlockField(index, 'name', e.target.value)}
                        placeholder={`Block ${String.fromCharCode(65 + index)}`}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-300">
                        Assigned Engineer <span className="text-amber-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={block.engineerName}
                        onChange={e => updateBlockField(index, 'engineerName', e.target.value)}
                        placeholder={index === 0 ? 'Ravi' : index === 1 ? 'Suresh' : 'Kiran'}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">
                          Workers
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={block.initialWorkers}
                          onChange={e =>
                            updateBlockField(index, 'initialWorkers', parseInt(e.target.value) || 1)
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-300">
                          Hours/Day
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="24"
                          value={block.plannedWorkingHours}
                          onChange={e =>
                            updateBlockField(index, 'plannedWorkingHours', parseFloat(e.target.value) || 1)
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Wizard Footer Buttons */}
        <div className="flex items-center justify-between border-t border-slate-800 pt-6">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => {
                setError('');
                setStep(step - 1);
              }}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs flex items-center gap-2 transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          <button
            type="button"
            onClick={handleNext}
            className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/25 flex items-center gap-2 transition transform active:scale-95"
          >
            <span>{step === 5 ? 'Create Project & Blocks' : 'Continue'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
