import React, { useState } from 'react';
import {
  FileSpreadsheet,
  PlusCircle,
  Calendar,
  Clock,
  Users,
  CheckCircle2,
  Trash2,
  Edit2,
  Sparkles,
  Layers,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { Task } from '../../types';

export const ConstructionPlan: React.FC = () => {
  const {
    activeProject,
    activeRole,
    addTaskToBlock,
    deleteTask,
    switchRole,
  } = useProject();

  const [selectedBlockId, setSelectedBlockId] = useState<string>(
    activeProject?.blocks[0]?.id || ''
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [taskName, setTaskName] = useState('');
  const [startDay, setStartDay] = useState<number>(1);
  const [endDay, setEndDay] = useState<number>(10);
  const [expectedProgress, setExpectedProgress] = useState<number>(35);
  const [expectedWorkers, setExpectedWorkers] = useState<number>(20);
  const [expectedWorkingHours, setExpectedWorkingHours] = useState<number>(7);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  if (!activeProject) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project selected. Please create or select a project.
      </div>
    );
  }

  const isMainEngineer = activeRole.type === 'MAIN_ENGINEER';
  const currentBlock =
    activeProject.blocks.find(b => b.id === selectedBlockId) || activeProject.blocks[0];

  const handleOpenModal = (blockId: string) => {
    setSelectedBlockId(blockId);
    setTaskName('');
    const targetBlock = activeProject.blocks.find(b => b.id === blockId);
    const existingTasksCount = targetBlock?.tasks?.length || 0;
    const nextStart = existingTasksCount > 0 ? (targetBlock?.tasks[existingTasksCount - 1]?.endDay || 1) + 1 : 1;
    const nextEnd = Math.min(activeProject.durationDays, nextStart + 9);
    
    setStartDay(nextStart);
    setEndDay(nextEnd);
    setExpectedProgress(Math.min(100, Math.round(((nextEnd / activeProject.durationDays) * 100))));
    setExpectedWorkers(targetBlock?.currentWorkers || targetBlock?.initialWorkers || 20);
    setExpectedWorkingHours(targetBlock?.currentWorkingHours || targetBlock?.plannedWorkingHours || 7);
    setNotes('');
    setError('');
    setIsModalOpen(true);
  };

  const handleSaveTask = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!taskName.trim()) {
      setError('Please enter a task name.');
      return;
    }
    if (startDay <= 0 || endDay < startDay) {
      setError('Start Day must be >= 1 and End Day must be >= Start Day.');
      return;
    }
    if (expectedProgress < 0 || expectedProgress > 100) {
      setError('Expected progress must be between 0% and 100%.');
      return;
    }

    addTaskToBlock(activeProject.id, selectedBlockId, {
      name: taskName.trim(),
      startDay: Number(startDay),
      endDay: Number(endDay),
      expectedProgress: Number(expectedProgress),
      expectedWorkers: Number(expectedWorkers),
      expectedWorkingHours: Number(expectedWorkingHours),
      notes: notes.trim(),
    });

    setIsModalOpen(false);
  };

  const handlePresetFill = (preset: { name: string; start: number; end: number; progress: number }) => {
    setTaskName(preset.name);
    setStartDay(preset.start);
    setEndDay(preset.end);
    setExpectedProgress(preset.progress);
  };

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-amber-400" />
              Construction Plan & Schedule Roadmap
            </h2>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Manual Plan
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Project: <strong className="text-white">{activeProject.name}</strong> ({activeProject.durationDays} Days Planned)
          </p>
        </div>

        {!isMainEngineer && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center gap-3 text-xs text-amber-300">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>Currently in Block Engineer view (Read-Only).</span>
            <button
              onClick={() => switchRole({ type: 'MAIN_ENGINEER' })}
              className="px-2.5 py-1 bg-amber-500 text-slate-950 font-bold rounded-lg hover:bg-amber-400 transition"
            >
              Switch to Main Engineer
            </button>
          </div>
        )}
      </div>

      {/* Block Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-2">
        {activeProject.blocks.map(block => {
          const isSelected = block.id === currentBlock?.id;
          const taskCount = block.tasks?.length || 0;

          return (
            <button
              key={block.id}
              onClick={() => setSelectedBlockId(block.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 border ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <Layers className={`w-3.5 h-3.5 ${isSelected ? 'text-slate-950' : 'text-slate-400'}`} />
              <span>{block.name}</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                  isSelected ? 'bg-slate-950/20 text-slate-950 font-extrabold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {taskCount} {taskCount === 1 ? 'Task' : 'Tasks'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Selected Block Plan Details */}
      {currentBlock && (
        <div className="space-y-6">
          {/* Block Overview Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">{currentBlock.name} Construction Plan</h3>
                <span className="text-xs text-slate-400">
                  (Engineer: <strong className="text-amber-400">{currentBlock.engineerName}</strong>)
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Initial Workers: {currentBlock.initialWorkers} • Planned Shift: {currentBlock.plannedWorkingHours} Hours/Day
              </p>
            </div>

            {isMainEngineer && (
              <button
                onClick={() => handleOpenModal(currentBlock.id)}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-2 transition"
              >
                <PlusCircle className="w-4 h-4" />
                <span>+ Add Task to {currentBlock.name}</span>
              </button>
            )}
          </div>

          {/* Tasks List / Timeline */}
          {(!currentBlock.tasks || currentBlock.tasks.length === 0) ? (
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-10 text-center space-y-4">
              <FileSpreadsheet className="w-12 h-12 text-slate-600 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white">No tasks created for {currentBlock.name} yet</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  The Main Engineer must manually add tasks (e.g. Foundation, Structural Framing, Masonry, Finishing) to define the schedule.
                </p>
              </div>
              {isMainEngineer && (
                <button
                  onClick={() => handleOpenModal(currentBlock.id)}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 inline-flex items-center gap-2 transition"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Create First Task</span>
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Chronological Task Cards */}
              <div className="grid grid-cols-1 gap-3">
                {currentBlock.tasks.map((task, idx) => (
                  <div
                    key={task.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 hover:border-slate-700 transition"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-400 text-xs font-bold flex items-center justify-center border border-amber-500/30">
                          {idx + 1}
                        </span>
                        <div>
                          <h4 className="text-sm font-bold text-white">{task.name}</h4>
                          <p className="text-[11px] text-slate-400">
                            Timeline: <strong className="text-slate-200">Day {task.startDay}</strong> to{' '}
                            <strong className="text-slate-200">Day {task.endDay}</strong> (
                            {task.endDay - task.startDay + 1} Days)
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-xs text-slate-400">Target Progress</p>
                          <p className="text-sm font-mono font-bold text-emerald-400">
                            {task.expectedProgress}%
                          </p>
                        </div>

                        {isMainEngineer && (
                          <button
                            onClick={() => deleteTask(activeProject.id, currentBlock.id, task.id)}
                            className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                            title="Delete Task"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Task Progress Timeline Bar */}
                    <div className="space-y-1">
                      <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800/80 flex">
                        <div
                          className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full"
                          style={{ width: `${task.expectedProgress}%` }}
                        />
                      </div>
                    </div>

                    {/* Resources & Notes */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs text-slate-400">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-blue-400" />
                          Expected: {task.expectedWorkers} Workers
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          {task.expectedWorkingHours} Hours/Day
                        </span>
                      </div>
                      {task.notes && (
                        <span className="italic text-slate-500 text-[11px]">
                          Note: {task.notes}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-amber-400" />
                  Add Task to {currentBlock?.name}
                </h3>
                <p className="text-xs text-slate-400">
                  Main Engineer Construction Plan Entry
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* Quick Presets for Demo */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-slate-400">
                Quick Task Templates:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { name: 'Site Excavation & Foundation', start: 1, end: 10, progress: 30 },
                  { name: 'Structural Columns & Beams', start: 11, end: 20, progress: 65 },
                  { name: 'Brickwork & Wall Construction', start: 21, end: 25, progress: 85 },
                  { name: 'Roofing, Electrical & Finishing', start: 26, end: activeProject.durationDays, progress: 100 },
                ].map((item, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handlePresetFill(item)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-medium text-slate-300 transition"
                  >
                    + {item.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSaveTask} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Task Name <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={taskName}
                  onChange={e => setTaskName(e.target.value)}
                  placeholder="e.g. Foundation & Excavation"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Start Day <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={activeProject.durationDays}
                    value={startDay}
                    onChange={e => setStartDay(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    End Day <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="number"
                    min={startDay}
                    max={activeProject.durationDays}
                    value={endDay}
                    onChange={e => setEndDay(parseInt(e.target.value) || startDay)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Expected Progress (%)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={expectedProgress}
                    onChange={e => setExpectedProgress(parseInt(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Expected Workers
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={expectedWorkers}
                    onChange={e => setExpectedWorkers(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Shift (Hours/Day)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="24"
                    value={expectedWorkingHours}
                    onChange={e => setExpectedWorkingHours(parseFloat(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Notes (Optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Ensure soil testing is verified before concrete pouring"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition"
                >
                  Save Task to Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
