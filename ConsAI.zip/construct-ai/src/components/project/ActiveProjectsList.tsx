import React from 'react';
import {
  FolderGit2,
  PlusCircle,
  MapPin,
  Calendar,
  Layers,
  ArrowRight,
  Trash2,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { calculateProjectOverview } from '../../services/deviationEngine';

interface ActiveProjectsListProps {
  onOpenProject: (projectId: string) => void;
  onCreateNew: () => void;
}

export const ActiveProjectsList: React.FC<ActiveProjectsListProps> = ({
  onOpenProject,
  onCreateNew,
}) => {
  const { projects, deleteProject } = useProject();

  const activeProjects = projects.filter(p => p.status !== 'COMPLETED');

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <FolderGit2 className="w-5 h-5 text-amber-400" />
              Active Construction Projects
            </h2>
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30">
              {activeProjects.length} Active
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Manage site plans, daily logs, and schedule tracking for ongoing sites.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/25 flex items-center gap-2 transition"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Create New Project</span>
        </button>
      </div>

      {activeProjects.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
          <FolderGit2 className="w-12 h-12 text-slate-600 mx-auto" />
          <h4 className="text-base font-bold text-white">No Active Projects</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Click "Create New Project" to manually start a new construction site monitoring project.
          </p>
          <button
            onClick={onCreateNew}
            className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-2 transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create New Project</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeProjects.map(project => {
            const overview = calculateProjectOverview(project);

            return (
              <div
                key={project.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5 hover:border-slate-700 transition flex flex-col justify-between"
              >
                <div className="space-y-4">
                  {/* Top Header */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold text-slate-400 block">{project.type}</span>
                      <h3 className="text-base font-bold text-white mt-0.5">{project.name}</h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                        <MapPin className="w-3 h-3 text-amber-400" />
                        {project.location}
                      </p>
                    </div>

                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border shrink-0 ${
                        project.status === 'DELAYED'
                          ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                          : project.status === 'AT_RISK'
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                      }`}
                    >
                      {project.status === 'DELAYED'
                        ? '🔴 Delay'
                        : project.status === 'AT_RISK'
                        ? '🟡 At Risk'
                        : '🟢 On Track'}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Overall Progress</span>
                      <span className="font-mono font-bold text-amber-400">
                        {overview.overallProgress}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden flex">
                      <div
                        className="h-full bg-amber-500 rounded-full"
                        style={{ width: `${overview.overallProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Quick Meta */}
                  <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800/80">
                    <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                      <span className="text-[10px] uppercase font-bold block">Blocks</span>
                      <span className="font-bold text-white text-xs">{project.blocks.length} Blocks</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                      <span className="text-[10px] uppercase font-bold block">Timeline</span>
                      <span className="font-bold text-white text-xs">Day {project.currentDay} / {project.durationDays}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => deleteProject(project.id)}
                    className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition"
                    title="Delete Project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onOpenProject(project.id)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition"
                  >
                    <span>Open Project</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
