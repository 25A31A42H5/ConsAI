import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Bot,
  Layers,
  ArrowRight,
  TrendingDown,
  Sparkles,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { analyzeBlockDeviation } from '../../services/deviationEngine';

interface DeviationTrackerProps {
  onOpenAIRecovery: (blockId?: string) => void;
}

export const DeviationTracker: React.FC<DeviationTrackerProps> = ({
  onOpenAIRecovery,
}) => {
  const { activeProject } = useProject();

  if (!activeProject) return null;

  return (
    <div className="space-y-6">
      {/* 3-Day Rule Explanation Banner */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Protocol
            </span>
            <h3 className="text-sm font-bold text-white">Three-Day Schedule Deviation Rule</h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
            The AI Recovery Assistant is activated exclusively when a block exceeds 3 days of estimated delay. Minor delays (0-3 days) continue standard monitoring.
          </p>
        </div>

        <div className="flex items-center gap-3 text-[11px] font-bold">
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            0–1d: On Track
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
            2–3d: At Risk
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30">
            &gt;3d: Significant Delay
          </span>
        </div>
      </div>

      {/* Block Deviation Comparison Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activeProject.blocks.map(block => {
          const dev = analyzeBlockDeviation(block, activeProject);
          const isSignificant = dev.status === 'SIGNIFICANT_DELAY';
          const isAtRisk = dev.status === 'AT_RISK';

          return (
            <div
              key={block.id}
              className={`rounded-2xl p-5 border transition-all space-y-4 ${
                isSignificant
                  ? 'bg-rose-950/20 border-rose-500/50 shadow-xl shadow-rose-500/5'
                  : isAtRisk
                  ? 'bg-amber-950/20 border-amber-500/40'
                  : 'bg-slate-900 border-slate-800'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-white text-base">{block.name}</h4>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        isSignificant
                          ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                          : isAtRisk
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                      }`}
                    >
                      {isSignificant
                        ? '🔴 Significant Delay'
                        : isAtRisk
                        ? '🟡 At Risk'
                        : '🟢 On Track'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Engineer: <strong className="text-slate-200">{block.engineerName}</strong>
                  </p>
                </div>
              </div>

              {/* Progress Gap & Delay Metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Progress Gap
                  </span>
                  <span
                    className={`font-mono font-bold text-base ${
                      dev.gapPercent > 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {dev.gapPercent > 0 ? `-${dev.gapPercent}%` : '0%'}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    Act: {dev.actualProgress}% / Plan: {dev.plannedProgress}%
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Estimated Delay
                  </span>
                  <span
                    className={`font-mono font-bold text-base ${
                      isSignificant
                        ? 'text-rose-400'
                        : isAtRisk
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {dev.estimatedDelayDays} Days
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {dev.remainingDays} Days Remaining
                  </span>
                </div>
              </div>

              {/* Status Message or AI Trigger */}
              {isSignificant ? (
                <div className="space-y-2 pt-1">
                  <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-[11px] text-rose-300 font-medium">
                    ⚠️ <strong>Delay Exceeds 3 Days:</strong> Schedule recovery required.
                  </div>
                  <button
                    onClick={() => onOpenAIRecovery(block.id)}
                    className="w-full py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 transition transform active:scale-95"
                  >
                    <Bot className="w-4 h-4" />
                    <span>Ask AI Recovery Assistant</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Within normal threshold. Continue regular daily tracking.</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
