import React, { useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Layers,
  Bot,
  Activity,
  Calendar,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import {
  analyzeBlockDeviation,
  calculatePlannedProgressForDay,
} from '../../services/deviationEngine';
import { DeviationTracker } from './DeviationTracker';

interface ProgressMonitoringProps {
  onOpenAIRecovery: (blockId?: string) => void;
}

export const ProgressMonitoring: React.FC<ProgressMonitoringProps> = ({
  onOpenAIRecovery,
}) => {
  const { activeProject } = useProject();
  const [selectedBlockId, setSelectedBlockId] = useState<string>('ALL');

  if (!activeProject) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project selected.
      </div>
    );
  }

  // Generate chart data across timeline from Day 1 to currentDay or durationDays
  const chartDaysCount = Math.max(activeProject.currentDay, 10);
  const chartData = Array.from({ length: chartDaysCount }, (_, i) => {
    const day = i + 1;
    const dayObj: any = { day: `Day ${day}` };

    if (selectedBlockId === 'ALL') {
      let totalPlanned = 0;
      let totalActual = 0;
      let count = 0;

      activeProject.blocks.forEach(b => {
        const planned = calculatePlannedProgressForDay(b, day, activeProject.durationDays);
        const entriesOnOrBefore = (b.dailyEntries || []).filter(e => e.dayNumber <= day);
        const latestEntry = entriesOnOrBefore.sort((x, y) => y.dayNumber - x.dayNumber)[0];
        const actual = latestEntry ? latestEntry.actualProgress : (day <= activeProject.currentDay ? b.currentProgress : null);

        totalPlanned += planned;
        if (actual !== null) {
          totalActual += actual;
          count++;
        }
      });

      dayObj.Planned = Math.round(totalPlanned / activeProject.blocks.length);
      dayObj.Actual = count > 0 ? Math.round(totalActual / activeProject.blocks.length) : (day <= activeProject.currentDay ? 0 : null);
    } else {
      const targetBlock = activeProject.blocks.find(b => b.id === selectedBlockId);
      if (targetBlock) {
        dayObj.Planned = calculatePlannedProgressForDay(targetBlock, day, activeProject.durationDays);
        const entriesOnOrBefore = (targetBlock.dailyEntries || []).filter(e => e.dayNumber <= day);
        const latestEntry = entriesOnOrBefore.sort((x, y) => y.dayNumber - x.dayNumber)[0];
        dayObj.Actual = latestEntry ? latestEntry.actualProgress : (day <= activeProject.currentDay ? targetBlock.currentProgress : null);
      }
    }

    return dayObj;
  });

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400" />
              Progress Monitoring & Deviation Analytics
            </h2>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30">
              Live Comparison
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Comparing Planned Progress vs. Manually Entered Actual Progress across all blocks
          </p>
        </div>

        {/* Filter Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setSelectedBlockId('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
              selectedBlockId === 'ALL'
                ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            All Blocks (Overall)
          </button>
          {activeProject.blocks.map(b => (
            <button
              key={b.id}
              onClick={() => setSelectedBlockId(b.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                selectedBlockId === b.id
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
              }`}
            >
              {b.name}
            </button>
          ))}
        </div>
      </div>

      {/* Planned vs Actual Recharts Visualizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Schedule Progress Curves (Planned vs. Actual)
            </h3>
            <p className="text-xs text-slate-400">
              Tracking timeline trajectory from Day 1 to Day {activeProject.currentDay} (Planned: {activeProject.durationDays} Days)
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-blue-400">
              <span className="w-3 h-1 bg-blue-500 rounded" />
              Planned Baseline
            </span>
            <span className="flex items-center gap-1.5 text-amber-400">
              <span className="w-3 h-1 bg-amber-500 rounded" />
              Actual Progress
            </span>
          </div>
        </div>

        {/* Recharts Chart Container */}
        <div className="h-72 w-full pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="plannedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="day" stroke="#64748b" textAnchor="end" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" domain={[0, 100]} tick={{ fontSize: 11 }} unit="%" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '1rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="Planned"
                stroke="#3b82f6"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#plannedGradient)"
              />
              <Area
                type="monotone"
                dataKey="Actual"
                stroke="#f59e0b"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#actualGradient)"
                connectNulls
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Continuous Deviation Tracker & 3-Day Rule Status */}
      <DeviationTracker onOpenAIRecovery={onOpenAIRecovery} />
    </div>
  );
};
