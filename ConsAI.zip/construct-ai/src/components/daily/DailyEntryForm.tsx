import React, { useState, useEffect } from 'react';
import {
  Layers,
  Calendar,
  Clock,
  Users,
  HardHat,
  CloudRain,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Sparkles,
  BookOpen,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { calculatePlannedProgressForDay } from '../../services/deviationEngine';
import { DailyEntrySummary } from './DailyEntrySummary';
import { DailyEntry } from '../../types';

interface DailyEntryFormProps {
  initialBlockId?: string;
  onEntrySubmitted?: () => void;
}

const WEATHER_OPTIONS = ['☀️ Sunny', '🌧️ Rain', '⛅ Cloudy', '🔥 High Temperature', '🌪️ Stormy', '🌫️ Foggy'];
const PROBLEM_PRESETS = [
  'Heavy Rainfall',
  'Material Delivery Delay',
  'Worker Shortage',
  'Equipment Breakdown',
  'Power Outage',
  'None (Normal Operations)',
];

export const DailyEntryForm: React.FC<DailyEntryFormProps> = ({
  initialBlockId,
  onEntrySubmitted,
}) => {
  const { activeProject, activeRole, addDailyEntry, switchRole } = useProject();

  const [selectedBlockId, setSelectedBlockId] = useState<string>(
    initialBlockId || activeProject?.blocks[0]?.id || ''
  );

  // If user is logged in as a Block Engineer, automatically lock to their block!
  useEffect(() => {
    if (activeRole.type === 'BLOCK_ENGINEER' && activeRole.blockId) {
      setSelectedBlockId(activeRole.blockId);
    } else if (initialBlockId) {
      setSelectedBlockId(initialBlockId);
    }
  }, [activeRole, initialBlockId]);

  const targetBlock =
    activeProject?.blocks.find(b => b.id === selectedBlockId) || activeProject?.blocks[0];

  // Auto-suggest next day number
  const nextDaySuggestion = targetBlock?.dailyEntries?.length
    ? Math.max(...targetBlock.dailyEntries.map(e => e.dayNumber)) + 1
    : activeProject?.currentDay || 1;

  const [dayNumber, setDayNumber] = useState<number>(nextDaySuggestion);
  const [entryDate, setEntryDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  const [actualProgress, setActualProgress] = useState<number>(
    targetBlock?.currentProgress || 0
  );
  const [workersPresent, setWorkersPresent] = useState<number>(
    targetBlock?.currentWorkers || targetBlock?.initialWorkers || 20
  );
  const [actualWorkingHours, setActualWorkingHours] = useState<number>(
    targetBlock?.currentWorkingHours || targetBlock?.plannedWorkingHours || 7
  );
  const [materialsUsed, setMaterialsUsed] = useState<string>(
    'Cement: 50 Bags\nSteel: 200 kg\nConcrete: 5 m³'
  );
  const [problems, setProblems] = useState<string>('None (Normal Operations)');
  const [weather, setWeather] = useState<string>('☀️ Sunny');
  const [engineerDiary, setEngineerDiary] = useState<string>('');
  const [submittedEntry, setSubmittedEntry] = useState<DailyEntry | null>(null);
  const [error, setError] = useState('');

  // Update planned progress and defaults when day or block changes
  useEffect(() => {
    if (targetBlock && activeProject) {
      const activeTask =
        targetBlock.tasks?.find(t => dayNumber >= t.startDay && dayNumber <= t.endDay) ||
        targetBlock.tasks?.[0];
      if (activeTask) {
        setSelectedTaskId(activeTask.id);
      }
      setWorkersPresent(targetBlock.currentWorkers || targetBlock.initialWorkers || 20);
      setActualWorkingHours(targetBlock.currentWorkingHours || targetBlock.plannedWorkingHours || 7);
    }
  }, [selectedBlockId, dayNumber, targetBlock, activeProject]);

  if (!activeProject || !targetBlock) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project or block found.
      </div>
    );
  }

  // Calculate planned progress for current dayNumber
  const plannedProgress = calculatePlannedProgressForDay(
    targetBlock,
    dayNumber,
    activeProject.durationDays
  );

  // Check if active role has permission for this block
  const isAllowedToEdit =
    activeRole.type === 'MAIN_ENGINEER' || activeRole.blockId === targetBlock.id;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!isAllowedToEdit) {
      setError(`Access Restricted: You are logged in as ${activeRole.blockName || 'another role'}. Switch to ${targetBlock.name} Engineer or Main Engineer.`);
      return;
    }

    if (dayNumber <= 0) {
      setError('Please enter a valid Day Number (>= 1).');
      return;
    }

    if (actualProgress < 0 || actualProgress > 100) {
      setError('Actual Progress achieved must be between 0% and 100%.');
      return;
    }

    if (!engineerDiary.trim()) {
      setError("Please write the Engineer's Daily Construction Diary. Manual diary entry is required.");
      return;
    }

    const selectedTask = targetBlock.tasks?.find(t => t.id === selectedTaskId);

    const baseDailyRate = 100 / Math.max(1, activeProject.durationDays);
    const gap = Math.max(0, plannedProgress - actualProgress);
    const estDelay = Math.round((gap / Math.max(1, baseDailyRate)) * 10) / 10;
    const deviationStatus = estDelay > 3 ? 'SIGNIFICANT_DELAY' : estDelay >= 2 ? 'AT_RISK' : 'ON_TRACK';

    const newEntry = addDailyEntry(activeProject.id, targetBlock.id, {
      blockId: targetBlock.id,
      dayNumber: Number(dayNumber),
      date: entryDate,
      taskId: selectedTaskId || 'task-gen',
      taskName: selectedTask?.name || 'General Construction',
      plannedProgress,
      actualProgress: Number(actualProgress),
      workersPresent: Number(workersPresent),
      actualWorkingHours: Number(actualWorkingHours),
      materialsUsed: materialsUsed.trim(),
      problems: problems.trim(),
      weather,
      engineerDiary: engineerDiary.trim(),
      status: deviationStatus,
    });

    setSubmittedEntry(newEntry);
    if (onEntrySubmitted) {
      onEntrySubmitted();
    }
  };

  const handleResetForNextEntry = () => {
    setSubmittedEntry(null);
    setDayNumber(prev => prev + 1);
    setEngineerDiary('');
  };

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-5xl mx-auto space-y-6">
      {/* Block Selector Tabs (if Main Engineer) */}
      {activeRole.type === 'MAIN_ENGINEER' ? (
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <span className="text-xs font-bold text-slate-400 mr-1">Select Block to Enter Data:</span>
          {activeProject.blocks.map(block => {
            const isSelected = block.id === selectedBlockId;
            return (
              <button
                key={block.id}
                onClick={() => {
                  setSelectedBlockId(block.id);
                  setSubmittedEntry(null);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{block.name}</span>
                <span className="text-[10px] text-slate-400">({block.engineerName})</span>
              </button>
            );
          })}
        </div>
      ) : (
        /* Block Engineer Scope Banner */
        <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <HardHat className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-xs font-bold text-white">
                Logged in as: <span className="text-blue-400">{targetBlock.engineerName}</span> ({targetBlock.name} Engineer)
              </p>
              <p className="text-[11px] text-slate-400">
                You have exclusive data entry access for {targetBlock.name}.
              </p>
            </div>
          </div>
          <button
            onClick={() => switchRole({ type: 'MAIN_ENGINEER' })}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Switch to Main Engineer
          </button>
        </div>
      )}

      {/* Submitted Entry Summary Card */}
      {submittedEntry ? (
        <DailyEntrySummary
          entry={submittedEntry}
          blockName={targetBlock.name}
          engineerName={targetBlock.engineerName}
          onAddNewEntry={handleResetForNextEntry}
        />
      ) : (
        /* Daily Entry Form Container */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-10 shadow-2xl space-y-8">
          {/* Header */}
          <div className="border-b border-slate-800 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-black text-white flex items-center gap-2">
                    Daily Construction Data Entry — {targetBlock.name}
                  </h2>
                  <p className="text-xs text-slate-400">
                    Engineer: <strong className="text-amber-400">{targetBlock.engineerName}</strong> • Project Day {activeProject.currentDay} of {activeProject.durationDays}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold">Planned for Day {dayNumber}:</span>
              <span className="px-3 py-1 bg-slate-950 rounded-xl border border-slate-700 font-mono font-bold text-amber-400 text-sm">
                {plannedProgress}%
              </span>
            </div>
          </div>

          {error && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Row 1: Day Number, Date, Task */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  Day Number <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max={activeProject.durationDays}
                  value={dayNumber}
                  onChange={e => setDayNumber(parseInt(e.target.value) || 1)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Date
                </label>
                <input
                  type="date"
                  value={entryDate}
                  onChange={e => setEntryDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Current Task <span className="text-amber-400">*</span>
                </label>
                <select
                  value={selectedTaskId}
                  onChange={e => setSelectedTaskId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                >
                  {(!targetBlock.tasks || targetBlock.tasks.length === 0) ? (
                    <option value="">General Work (No Plan Tasks Added)</option>
                  ) : (
                    targetBlock.tasks.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name} (Day {t.startDay}-{t.endDay} @ {t.expectedProgress}%)
                      </option>
                    ))
                  )}
                </select>
              </div>
            </div>

            {/* Row 2: Progress, Workers, Working Hours */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300">
                    Actual Progress Achieved (%) <span className="text-amber-400">*</span>
                  </label>
                  <span className="text-[11px] text-slate-400">Planned: {plannedProgress}%</span>
                </div>
                <input
                  type="number"
                  min="0"
                  max="100"
                  required
                  value={actualProgress}
                  onChange={e => setActualProgress(parseFloat(e.target.value) || 0)}
                  placeholder="e.g. 55"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-amber-400 font-mono text-base font-bold focus:outline-none focus:border-amber-500"
                />
                <p className="text-[10px] text-slate-400">
                  Cumulative progress achieved across the block to date.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-400" />
                  Workers Present Today <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={workersPresent}
                  onChange={e => setWorkersPresent(parseInt(e.target.value) || 1)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Actual Working Hours Today <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min="1"
                  max="24"
                  step="0.5"
                  required
                  value={actualWorkingHours}
                  onChange={e => setActualWorkingHours(parseFloat(e.target.value) || 1)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-bold focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Row 3: Weather & Problems / Issues */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <CloudRain className="w-3.5 h-3.5 text-blue-400" />
                  Weather / External Conditions
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {WEATHER_OPTIONS.map(opt => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setWeather(opt)}
                      className={`p-2 rounded-xl text-xs font-medium border text-center transition ${
                        weather === opt
                          ? 'bg-blue-500/20 text-blue-300 border-blue-500 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  Site Problems / Delay Issues
                </label>
                <input
                  type="text"
                  value={problems}
                  onChange={e => setProblems(e.target.value)}
                  placeholder="e.g. Heavy Rainfall, Material shortage"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500"
                />
                <div className="flex flex-wrap gap-1">
                  {PROBLEM_PRESETS.slice(0, 4).map(preset => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setProblems(preset)}
                      className="px-2 py-0.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-[10px] text-slate-300 transition"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Row 4: Materials Used */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Materials Used (Flexible Text / Itemized)
              </label>
              <textarea
                rows={2}
                value={materialsUsed}
                onChange={e => setMaterialsUsed(e.target.value)}
                placeholder="Cement: 50 Bags&#10;Steel: 200 kg&#10;Concrete: 5 m³"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-500 font-mono"
              />
            </div>

            {/* Row 5: ENGINEER'S DAILY CONSTRUCTION DIARY (Major Feature!) */}
            <div className="space-y-2 p-5 rounded-2xl bg-amber-500/5 border border-amber-500/30">
              <div className="flex items-center justify-between">
                <label className="text-sm font-extrabold text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-amber-400" />
                  ENGINEER'S DAILY CONSTRUCTION DIARY <span className="text-amber-400">*</span>
                </label>
                <span className="text-[11px] font-bold text-amber-400/90 uppercase tracking-wider">
                  Mandatory Manual Entry
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Describe everything important that happened in {targetBlock.name} today (work accomplished, disruptions, site conditions, decisions).
              </p>
              <textarea
                required
                rows={4}
                value={engineerDiary}
                onChange={e => setEngineerDiary(e.target.value)}
                placeholder="e.g. Today we continued foundation excavation. Twenty workers were present. Heavy rainfall stopped work for approximately 3 hours around noon. As a result, concrete pouring was deferred to tomorrow morning and actual progress was lower than planned."
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-amber-500/40 text-white text-xs leading-relaxed focus:outline-none focus:border-amber-500 placeholder:text-slate-600 transition"
              />
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Stored permanently in project historical record.</span>
                {/* Demo Helper snippet */}
                <button
                  type="button"
                  onClick={() =>
                    setEngineerDiary(
                      `Today on Day ${dayNumber} we operated with ${workersPresent} workers on ${targetBlock.name}. Weather was ${weather}. Progress reached ${actualProgress}%. ${problems !== 'None (Normal Operations)' ? `Faced disruptions due to ${problems}, which slowed down the scheduled tasks.` : 'Work proceeded as scheduled with steady milestone execution.'}`
                    )
                  }
                  className="text-amber-400 hover:underline text-[11px] font-semibold"
                >
                  Quick Fill Diary Text
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <div className="text-xs text-slate-400">
                <span>Saving updates {targetBlock.name} progress & continuous diary archive.</span>
              </div>
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/25 flex items-center gap-2 transition transform active:scale-95"
              >
                <span>Submit Day {dayNumber} Construction Entry</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
