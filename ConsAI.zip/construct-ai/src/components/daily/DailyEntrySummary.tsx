import React from 'react';
import { CheckCircle2, AlertTriangle, ArrowRight, BookOpen, Clock, Users, CloudRain, Package, Layers } from 'lucide-react';
import { DailyEntry } from '../../types';

interface DailyEntrySummaryProps {
  entry: DailyEntry;
  blockName: string;
  engineerName: string;
  onAddNewEntry: () => void;
}

export const DailyEntrySummary: React.FC<DailyEntrySummaryProps> = ({
  entry,
  blockName,
  engineerName,
  onAddNewEntry,
}) => {
  const gap = entry.plannedProgress - entry.actualProgress;
  const isDelayed = entry.status === 'SIGNIFICANT_DELAY';
  const isAtRisk = entry.status === 'AT_RISK';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-10 shadow-2xl space-y-6 animate-in fade-in">
      {/* Header Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">
                DAY {entry.dayNumber} — {blockName.toUpperCase()}
              </h2>
              <span
                className={`text-xs font-black uppercase px-2.5 py-0.5 rounded-full border ${
                  isDelayed
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                    : isAtRisk
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                }`}
              >
                {isDelayed ? '🔴 >3d Delay' : isAtRisk ? '⚠️ At Risk' : '🟢 On Track'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Engineer: <strong className="text-white">{engineerName}</strong> • Date: {entry.date} • Task: {entry.taskName}
            </p>
          </div>
        </div>

        <button
          onClick={onAddNewEntry}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-2 transition"
        >
          <span>+ Add Next Day's Entry</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Metric Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400">Planned Progress</span>
          <p className="text-xl font-mono font-bold text-slate-300">{entry.plannedProgress}%</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400">Actual Progress</span>
          <p className="text-xl font-mono font-bold text-amber-400">{entry.actualProgress}%</p>
          {gap > 0 && (
            <span className="text-[10px] text-rose-400 font-semibold block">
              Gap: -{gap}%
            </span>
          )}
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <Users className="w-3 h-3 text-blue-400" />
            Workers Present
          </span>
          <p className="text-xl font-mono font-bold text-white">{entry.workersPresent}</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-400" />
            Working Hours
          </span>
          <p className="text-xl font-mono font-bold text-white">{entry.actualWorkingHours} hrs</p>
        </div>
      </div>

      {/* Conditions & Issues */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
            <CloudRain className="w-3.5 h-3.5 text-blue-400" />
            Weather Condition
          </span>
          <p className="text-xs font-bold text-slate-200">{entry.weather}</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Reported Issue
          </span>
          <p className="text-xs font-bold text-amber-300">{entry.problems || 'None'}</p>
        </div>
      </div>

      {/* Materials Used */}
      {entry.materialsUsed && (
        <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1.5">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-slate-400" />
            Materials Consumed
          </span>
          <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap">
            {entry.materialsUsed}
          </pre>
        </div>
      )}

      {/* Engineer's Diary Content */}
      <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Recorded Engineer Diary Entry
          </h4>
        </div>
        <p className="text-xs text-slate-200 leading-relaxed italic bg-slate-950/80 p-4 rounded-xl border border-slate-800">
          "{entry.engineerDiary}"
        </p>
      </div>

      <div className="text-center text-[11px] text-slate-500">
        ✓ This entry is stored permanently in localStorage historical records.
      </div>
    </div>
  );
};
