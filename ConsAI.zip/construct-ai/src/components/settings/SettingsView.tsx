import React, { useState } from 'react';
import {
  Settings,
  Trash2,
  Database,
  RefreshCw,
  HardHat,
  Sparkles,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { useAuth } from '../../context/AuthContext';

interface SettingsViewProps {
  onOpenGuide: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenGuide }) => {
  const { projects, resetAll } = useProject();
  const { user } = useAuth();
  const [resetSuccess, setResetSuccess] = useState(false);

  const totalBlocks = projects.reduce((acc, p) => acc + p.blocks.length, 0);
  const totalDiaries = projects.reduce(
    (acc, p) => acc + p.blocks.reduce((bAcc, b) => bAcc + (b.dailyEntries?.length || 0), 0),
    0
  );
  const totalRecoveries = projects.reduce((acc, p) => acc + (p.recoveryLogs?.length || 0), 0);

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset all local projects and start with a clean empty state for testing?')) {
      resetAll();
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 3000);
    }
  };

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">System Settings & Data Storage</h2>
            <p className="text-xs text-slate-400">
              Manage local browser storage, prototype state, and test configurations.
            </p>
          </div>
        </div>
      </div>

      {resetSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Local storage cleared successfully. Dashboard is now in clean empty state.</span>
        </div>
      )}

      {/* Storage Diagnostics */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Database className="w-4 h-4 text-blue-400" />
          Local Storage Diagnostics
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Projects</span>
            <span className="text-lg font-bold text-white mt-0.5 block">{projects.length}</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Blocks</span>
            <span className="text-lg font-bold text-white mt-0.5 block">{totalBlocks}</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Diaries</span>
            <span className="text-lg font-bold text-amber-400 mt-0.5 block">{totalDiaries}</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">AI Analyses</span>
            <span className="text-lg font-bold text-indigo-400 mt-0.5 block">{totalRecoveries}</span>
          </div>
        </div>
      </div>

      {/* Demonstration Guide Shortcut */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">25-Step Prototype Test Script</h4>
              <p className="text-xs text-slate-400">
                Open the interactive step-by-step evaluation guide for professors and evaluators.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenGuide}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition"
          >
            Open Test Guide
          </button>
        </div>
      </div>

      {/* Danger Zone / Reset */}
      <div className="bg-rose-950/10 border border-rose-500/30 rounded-3xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
          <AlertTriangle className="w-4 h-4" />
          <span>Reset Prototype Data</span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Clear all projects, blocks, plans, and daily diary entries from browser localStorage. Use this if you want to restart your evaluation demo with a 100% empty dashboard.
        </p>

        <button
          onClick={handleResetData}
          className="px-5 py-2.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs flex items-center gap-2 transition"
        >
          <Trash2 className="w-4 h-4" />
          <span>Reset All Data to Clean Empty State</span>
        </button>
      </div>
    </div>
  );
};
