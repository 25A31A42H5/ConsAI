import React, { useState } from 'react';
import {
  Bot,
  Sparkles,
  Clock,
  Users,
  Shuffle,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileText,
  ShieldCheck,
  ArrowRight,
  Info,
  ShieldAlert,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { AIRecoveryAnalysis } from '../../types';
import { analyzeBlockDeviation } from '../../services/deviationEngine';

interface AIRecoveryAssistantProps {
  initialBlockId?: string;
  onClose?: () => void;
}

export const AIRecoveryAssistant: React.FC<AIRecoveryAssistantProps> = ({
  initialBlockId,
  onClose,
}) => {
  const {
    activeProject,
    activeRole,
    triggerAIRecovery,
    approveRecovery,
    rejectRecovery,
    switchRole,
  } = useProject();

  const [selectedBlockId, setSelectedBlockId] = useState<string>(
    initialBlockId || activeProject?.blocks[0]?.id || ''
  );

  const [currentAnalysis, setCurrentAnalysis] = useState<AIRecoveryAnalysis | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  if (!activeProject) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active project selected.
      </div>
    );
  }

  // Delayed blocks that meet the 3-day rule
  const delayedBlocks = activeProject.blocks.filter(b => {
    const dev = analyzeBlockDeviation(b, activeProject);
    return dev.status === 'SIGNIFICANT_DELAY';
  });

  const targetBlock =
    activeProject.blocks.find(b => b.id === selectedBlockId) || delayedBlocks[0] || activeProject.blocks[0];

  const targetDeviation = analyzeBlockDeviation(targetBlock, activeProject);

  // Latest saved recovery analysis for this block if existing
  const savedAnalysis = (activeProject.recoveryLogs || []).find(
    r => r.blockId === targetBlock.id
  );
  const activeReport = currentAnalysis || savedAnalysis;

  const handleRunSimulation = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const result = triggerAIRecovery(activeProject.id, targetBlock.id);
      setCurrentAnalysis(result);
      setIsGenerating(false);
    }, 400);
  };

  const handleApprove = (recId: string) => {
    approveRecovery(activeProject.id, recId);
    if (currentAnalysis) {
      setCurrentAnalysis({ ...currentAnalysis, status: 'APPROVED' });
    }
  };

  const handleReject = (recId: string) => {
    rejectRecovery(activeProject.id, recId);
    if (currentAnalysis) {
      setCurrentAnalysis({ ...currentAnalysis, status: 'REJECTED' });
    }
  };

  const isMainEngineer = activeRole.type === 'MAIN_ENGINEER';

  return (
    <div className="flex-1 p-4 lg:p-8 max-w-6xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">
                AI-Assisted Schedule Recovery Assistant
              </h2>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40">
                Simulation Engine
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Analyzes manually entered daily progress, diaries, worker counts, and site issues to simulate schedule recovery.
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
          >
            Close
          </button>
        )}
      </div>

      {/* Block Selector */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        <span className="text-xs font-bold text-slate-400 mr-2">Select Target Block:</span>
        {activeProject.blocks.map(b => {
          const dev = analyzeBlockDeviation(b, activeProject);
          const isSelected = b.id === targetBlock.id;
          const isSignificant = dev.status === 'SIGNIFICANT_DELAY';

          return (
            <button
              key={b.id}
              onClick={() => {
                setSelectedBlockId(b.id);
                setCurrentAnalysis(null);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 border ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md shadow-amber-500/20'
                  : isSignificant
                  ? 'bg-rose-950/40 text-rose-300 border-rose-500/40 hover:bg-rose-900/40'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <span>{b.name}</span>
              {isSignificant && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-500 text-white font-black">
                  &gt;3d Delay
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Target Block Status Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">Target: {targetBlock.name}</h3>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                  targetDeviation.status === 'SIGNIFICANT_DELAY'
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                    : targetDeviation.status === 'AT_RISK'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                }`}
              >
                {targetDeviation.status === 'SIGNIFICANT_DELAY'
                  ? '🔴 Significant Delay (>3 Days)'
                  : targetDeviation.status === 'AT_RISK'
                  ? '🟡 At Risk (2-3 Days)'
                  : '🟢 On Track (0-1 Days)'}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Assigned Engineer: <strong className="text-slate-200">{targetBlock.engineerName}</strong> • Current Workforce: {targetBlock.currentWorkers || targetBlock.initialWorkers} Workers @ {targetBlock.currentWorkingHours || targetBlock.plannedWorkingHours} hrs/day
            </p>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isGenerating}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs shadow-xl shadow-amber-500/25 flex items-center gap-2 transition transform active:scale-95 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>{isGenerating ? 'Analyzing Site Logs...' : 'Generate AI Recovery Simulation'}</span>
          </button>
        </div>

        {/* Delay Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-semibold">Planned Progress</span>
            <p className="text-xl font-mono font-bold text-slate-300">{targetDeviation.plannedProgress}%</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-semibold">Actual Progress</span>
            <p className="text-xl font-mono font-bold text-amber-400">{targetDeviation.actualProgress}%</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-semibold">Progress Gap</span>
            <p className="text-xl font-mono font-bold text-rose-400">-{targetDeviation.gapPercent}%</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-semibold">Estimated Delay</span>
            <p className="text-xl font-mono font-bold text-rose-400">{targetDeviation.estimatedDelayDays} Days</p>
          </div>
        </div>
      </div>

      {/* Generated AI Recovery Report */}
      {activeReport ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-10 shadow-2xl space-y-8 animate-in fade-in">
          {/* Report Title */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-amber-400">
                  Simulation Report
                </span>
                <h3 className="text-xl font-black text-white">
                  🤖 AI-Assisted Recovery Analysis
                </h3>
              </div>
              <p className="text-xs text-slate-400">
                Generated from manually entered progress, site issues, and diary logs for {activeReport.blockName}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`text-xs font-bold px-3 py-1 rounded-full border ${
                  activeReport.status === 'APPROVED'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    : activeReport.status === 'REJECTED'
                    ? 'bg-slate-800 text-slate-400 border-slate-700'
                    : 'bg-amber-500/20 text-amber-400 border-amber-500/40 animate-pulse'
                }`}
              >
                {activeReport.status === 'APPROVED'
                  ? '✅ APPROVED & APPLIED'
                  : activeReport.status === 'REJECTED'
                  ? '❌ REJECTED'
                  : '⏳ AWAITING MAIN ENGINEER REVIEW'}
              </span>
            </div>
          </div>

          {/* AI Rationale & Delay Drivers */}
          <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
              <Info className="w-4 h-4 text-amber-400" />
              AI Diagnosis & Context Analysis
            </div>
            <p className="text-xs text-slate-200 leading-relaxed">
              {activeReport.aiRationale}
            </p>
          </div>

          {/* Recommended Recovery Actions */}
          <div className="space-y-4">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
              <span>Recommended Recovery Actions</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Action 1: Adjust Working Hours */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2.5 text-amber-400">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center">
                    <Clock className="w-4 h-4" />
                  </div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-white">
                    1. Adjust Working Hours
                  </h5>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Current Shift:</span>
                    <span className="font-bold">{activeReport.currentHours} Hours/Day</span>
                  </div>
                  <div className="flex justify-between text-amber-400 font-bold">
                    <span>Recommended:</span>
                    <span>{activeReport.recommendedHours} Hours/Day</span>
                  </div>
                  <div className="flex justify-between text-emerald-400 text-[11px] font-semibold pt-1 border-t border-slate-800">
                    <span>Additional:</span>
                    <span>+{activeReport.extraHours} Hours/Day</span>
                  </div>
                </div>
              </div>

              {/* Action 2: Workforce Adjustment */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2.5 text-blue-400">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/20 flex items-center justify-center">
                    <Users className="w-4 h-4" />
                  </div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-white">
                    2. Workforce Adjustment
                  </h5>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Current Workers:</span>
                    <span className="font-bold">{activeReport.currentWorkers} Workers</span>
                  </div>
                  <div className="flex justify-between text-blue-400 font-bold">
                    <span>Recommended:</span>
                    <span>{activeReport.recommendedWorkers} Workers</span>
                  </div>
                  <div className="flex justify-between text-emerald-400 text-[11px] font-semibold pt-1 border-t border-slate-800">
                    <span>Additional Workers:</span>
                    <span>+{activeReport.extraWorkers} Workers Needed</span>
                  </div>
                </div>
              </div>

              {/* Action 3: Workforce Reallocation Opportunity */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2.5 text-emerald-400">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <Shuffle className="w-4 h-4" />
                  </div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-white">
                    3. Cross-Block Reallocation
                  </h5>
                </div>

                {activeReport.reallocationOpportunity ? (
                  <div className="space-y-1.5 text-xs text-slate-300">
                    <p className="text-[11px] text-emerald-400 font-semibold">
                      Opportunity Identified:
                    </p>
                    <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-[11px] text-emerald-200">
                      Temporarily transfer <strong>{activeReport.reallocationOpportunity.workersToReallocate} workers</strong> from{' '}
                      <strong>{activeReport.reallocationOpportunity.fromBlockName}</strong> to{' '}
                      <strong>{activeReport.blockName}</strong>.
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      {activeReport.reallocationOpportunity.rationale}
                    </p>
                  </div>
                ) : (
                  <div className="text-xs text-slate-400 py-2">
                    No ahead-of-schedule blocks currently available for labor transfer. Direct recruitment recommended.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Action 4: Recovery Monitoring Checkpoint */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>
                <strong>Recovery Monitoring Checkpoint:</strong> Review actual progress after the next{' '}
                <strong className="text-amber-400">2 Working Days</strong>.
              </span>
            </div>
            <span className="text-[11px] text-slate-400">Next Audit: Day {activeProject.currentDay + 2}</span>
          </div>

          {/* Mandatory Prototype Simulation Disclaimer */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300/90 leading-relaxed">
            <p>
              <strong>AI-Assisted Prototype Simulation:</strong> {activeReport.disclaimer}
            </p>
          </div>

          {/* Main Engineer Approval Controls */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400">
              {isMainEngineer ? (
                <span>As Main Engineer, you can approve or reject these recommendations.</span>
              ) : (
                <div className="flex items-center gap-2 text-amber-400">
                  <ShieldAlert className="w-4 h-4" />
                  <span>Only the Main Engineer role can approve or reject recovery simulations.</span>
                  <button
                    onClick={() => switchRole({ type: 'MAIN_ENGINEER' })}
                    className="underline font-bold"
                  >
                    Switch to Main Engineer
                  </button>
                </div>
              )}
            </div>

            {isMainEngineer && activeReport.status === 'RECOMMENDED' && (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleReject(activeReport.id)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <XCircle className="w-4 h-4 text-slate-400" />
                  <span>Reject</span>
                </button>
                <button
                  onClick={() => handleApprove(activeReport.id)}
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 transition transform active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4 text-slate-950" />
                  <span>Approve & Apply Plan Adjustments</span>
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
          <Bot className="w-12 h-12 text-slate-600 mx-auto" />
          <div className="space-y-1">
            <h4 className="text-base font-bold text-white">No AI Simulation Run Yet for {targetBlock.name}</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Click "Generate AI Recovery Simulation" above to analyze the manually entered daily logs and simulate workforce/hours adjustments.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
