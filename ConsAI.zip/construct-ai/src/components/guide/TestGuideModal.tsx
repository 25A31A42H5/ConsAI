import React, { useState } from 'react';
import { X, CheckCircle, ChevronRight, Sparkles, BookOpen, AlertCircle } from 'lucide-react';

interface TestGuideModalProps {
  onClose: () => void;
}

export const TestGuideModal: React.FC<TestGuideModalProps> = ({ onClose }) => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      num: 'STEP 1',
      title: 'Create Account / Login',
      desc: 'Use any email (e.g. engineer@constructai.local) and password to login or create an account.',
    },
    {
      num: 'STEP 2',
      title: 'Open Empty Dashboard',
      desc: 'Notice the dashboard starts 100% EMPTY with zero fake/preloaded projects.',
    },
    {
      num: 'STEP 3-7',
      title: 'Create New Project Manually',
      desc: 'Click "Create New Project". Enter Project Name ("Surampalem Engineering College"), Location ("Surampalem"), Type ("🏫 Engineering College"), Duration ("30 Days"), and Number of Blocks ("3").',
    },
    {
      num: 'STEP 8',
      title: 'Assign Block Engineers & Workers',
      desc: 'Set Block A (Ravi, 20 workers, 7h), Block B (Suresh, 25 workers, 7h), Block C (Kiran, 30 workers, 7h).',
    },
    {
      num: 'STEP 9-10',
      title: 'Main Engineer Creates Construction Plan',
      desc: 'Go to "Construction Plans". Add tasks (e.g. Foundation Day 1-10 @ 35%, Structural Frame Day 11-20 @ 70%, Finishing Day 21-30 @ 100%).',
    },
    {
      num: 'STEP 11-13',
      title: 'Block A: Day 1 Daily Entry & Diary',
      desc: 'Switch role to "Block A Engineer (Ravi)". Go to "Daily Entry". Enter Day 1: Actual 5%, Workers 20, Hours 7, Weather Sunny. Write the Engineer Diary manually.',
    },
    {
      num: 'STEP 14-16',
      title: 'Create a Deliberate Delay on Block B',
      desc: 'Switch to "Block B Engineer (Suresh)". Advance to Day 5 or Day 10. Enter Actual Progress: 15% (while Planned is 35%). Problem: "Heavy Rainfall & Labor Shortage". Write Diary explaining the rain stoppage.',
    },
    {
      num: 'STEP 17-18',
      title: 'Deviation Engine & 3-Day Rule Trigger',
      desc: 'Deviation engine calculates Block B is >3 days delayed. Notice the "⚠️ SIGNIFICANT SCHEDULE DEVIATION DETECTED" alert and unlocked "🤖 Ask AI Recovery Assistant" button.',
    },
    {
      num: 'STEP 19-21',
      title: 'AI Recovery Simulation & Approval',
      desc: 'Click "🤖 Ask AI Recovery Assistant". AI analyzes manual logs and recommends: (1) Overtime (+1.5h/d), (2) Extra workers (+4), (3) Cross-block reallocation (Move 4 workers from ahead-of-schedule Block C to Block B). Switch to Main Engineer to Approve/Reject.',
    },
    {
      num: 'STEP 22-25',
      title: 'Reach 100% & Inspect Complete Archive',
      desc: 'Enter continuous daily data until 100% completion. The project moves to "Completed Projects" with all permanent diaries, material logs, and AI reports intact.',
    },
  ];

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Prototype Demonstration Guide
                <span className="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">
                  25-Step Script
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Follow this guide to demonstrate ConstructAI's complete manual workflow
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps Content */}
        <div className="space-y-3 overflow-y-auto pr-1 flex-1">
          {steps.map((step, idx) => {
            const isCurrent = activeStep === idx;
            return (
              <div
                key={idx}
                onClick={() => setActiveStep(idx)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-indigo-950/40 border-indigo-500/60 shadow-lg shadow-indigo-500/5'
                    : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                    {step.num}
                  </span>
                  <span className="text-[10px] text-slate-400">Step {idx + 1} of {steps.length}</span>
                </div>
                <h4 className="text-sm font-bold text-white mt-1">{step.title}</h4>
                <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">{step.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>AI analyzes manually entered daily data when schedule deviation &gt; 3 days.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition text-xs shadow-md shadow-amber-500/20"
          >
            Got It, Let's Test!
          </button>
        </div>
      </div>
    </div>
  );
};
