import React, { useState } from 'react';
import {
  HardHat,
  ChevronDown,
  UserCheck,
  Calendar,
  AlertTriangle,
  LogOut,
  HelpCircle,
  PlusCircle,
  CheckCircle2,
  FastForward,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useProject } from '../../context/ProjectContext';
import { RoleSwitcherModal } from './RoleSwitcherModal';
import { TestGuideModal } from '../guide/TestGuideModal';

interface NavbarProps {
  onNavigate: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const { user, logout } = useAuth();
  const {
    projects,
    activeProject,
    selectProject,
    activeRole,
    advanceProjectDay,
  } = useProject();

  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [showProjectDropdown, setShowProjectDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  // Active role display string
  const getRoleDisplayName = () => {
    if (activeRole.type === 'MAIN_ENGINEER') {
      return '👷‍♂️ Main Engineer (Full Access)';
    }
    const currentBlock = activeProject?.blocks.find(b => b.id === activeRole.blockId);
    return `👷 ${currentBlock?.name || 'Block'} Engineer (${currentBlock?.engineerName || 'Assigned'})`;
  };

  return (
    <>
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 px-4 lg:px-6 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 flex items-center justify-center shadow-lg shadow-amber-500/20 text-slate-950 font-black">
              <HardHat className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white flex items-center gap-1.5">
                  Construct<span className="text-amber-400">AI</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  Prototype
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Construction Monitoring & Schedule Recovery
              </p>
            </div>
          </div>

          {/* Project Selector & Day Controls (if active project exists) */}
          {activeProject && (
            <div className="hidden md:flex items-center gap-3">
              {/* Project Picker Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowProjectDropdown(!showProjectDropdown)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700 hover:border-amber-500/50 text-slate-200 text-sm font-medium transition-all"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="max-w-[160px] truncate">{activeProject.name}</span>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>

                {showProjectDropdown && (
                  <div className="absolute left-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                    <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                      Switch Project
                    </div>
                    <div className="max-h-56 overflow-y-auto py-1">
                      {projects.map(p => (
                        <button
                          key={p.id}
                          onClick={() => {
                            selectProject(p.id);
                            setShowProjectDropdown(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between hover:bg-slate-800 ${
                            p.id === activeProject.id ? 'text-amber-400 font-semibold bg-amber-500/5' : 'text-slate-300'
                          }`}
                        >
                          <span className="truncate">{p.name}</span>
                          {p.id === activeProject.id && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                        </button>
                      ))}
                    </div>
                    <div className="pt-1 border-t border-slate-800 px-2">
                      <button
                        onClick={() => {
                          setShowProjectDropdown(false);
                          onNavigate('create_project');
                        }}
                        className="w-full flex items-center gap-2 px-2 py-1.5 text-xs text-amber-400 hover:bg-amber-500/10 rounded-lg transition"
                      >
                        <PlusCircle className="w-4 h-4" />
                        Create New Project
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Day Progression Indicator & Advance Button */}
              <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700 px-3 py-1 rounded-lg text-xs">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-slate-400">Day:</span>
                <span className="font-bold text-white text-sm">
                  {activeProject.currentDay} / {activeProject.durationDays}
                </span>
                {activeRole.type === 'MAIN_ENGINEER' && activeProject.currentDay < activeProject.durationDays && (
                  <button
                    onClick={() => advanceProjectDay(activeProject.id)}
                    title="Advance to Next Day"
                    className="ml-1 px-2 py-0.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[11px] flex items-center gap-1 transition"
                  >
                    <FastForward className="w-3 h-3" />
                    +1 Day
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Right Action Controls: Role Switcher, Test Guide, User Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Quick Demo Test Guide Button */}
            <button
              onClick={() => setShowGuideModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-600/30 text-xs font-semibold transition shadow-sm"
              title="Step-by-step prototype demonstration guide"
            >
              <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Demo Test Guide</span>
            </button>

            {/* Role Switcher Button */}
            <button
              onClick={() => setShowRoleModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-300 hover:bg-amber-500/25 text-xs font-semibold transition"
            >
              <UserCheck className="w-3.5 h-3.5 text-amber-400" />
              <span className="max-w-[140px] truncate">{getRoleDisplayName()}</span>
              <span className="text-[10px] bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded font-bold uppercase">
                Switch
              </span>
            </button>

            {/* User Avatar & Logout */}
            <div className="relative">
              <button
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 hover:border-slate-600 flex items-center justify-center text-xs font-bold text-amber-400 transition"
              >
                {user?.name ? user.name.substring(0, 2).toUpperCase() : 'AI'}
              </button>

              {showUserDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                  <div className="px-3 py-1.5 border-b border-slate-800">
                    <p className="text-xs font-bold text-white truncate">{user?.name || 'Engineer'}</p>
                    <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                  </div>
                  <button
                    onClick={() => {
                      setShowUserDropdown(false);
                      onNavigate('settings');
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-slate-800 transition"
                  >
                    ⚙️ Settings & Reset Data
                  </button>
                  <button
                    onClick={() => {
                      setShowUserDropdown(false);
                      logout();
                    }}
                    className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 transition"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Role Switcher Modal */}
      {showRoleModal && <RoleSwitcherModal onClose={() => setShowRoleModal(false)} />}

      {/* Test Guide Walkthrough Modal */}
      {showGuideModal && <TestGuideModal onClose={() => setShowGuideModal(false)} />}
    </>
  );
};
