import React from 'react';
import {
  LayoutDashboard,
  FolderGit2,
  PlusSquare,
  FileSpreadsheet,
  LineChart,
  BookOpenCheck,
  Bot,
  CheckCircle2,
  Settings,
  Sparkles,
  Layers,
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { calculateProjectOverview } from '../../services/deviationEngine';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate }) => {
  const { activeProject, activeRole } = useProject();

  const overview = activeProject ? calculateProjectOverview(activeProject) : null;
  const hasSignificantDelay = overview?.hasSignificantDelay || false;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'active_projects', label: 'Active Projects', icon: FolderGit2, badge: null },
    { id: 'create_project', label: 'Create Project', icon: PlusSquare, badge: null },
    { id: 'plans', label: 'Construction Plans', icon: FileSpreadsheet, badge: null },
    { id: 'daily_entry', label: 'Daily Entry', icon: Layers, badge: null },
    { id: 'monitoring', label: 'Monitoring', icon: LineChart, badge: null },
    { id: 'diaries', label: 'Daily Diaries', icon: BookOpenCheck, badge: null },
    {
      id: 'ai_recovery',
      label: 'AI Recovery',
      icon: Bot,
      badge: hasSignificantDelay ? (
        <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white animate-pulse">
          Delay
        </span>
      ) : null,
    },
    { id: 'completed', label: 'Completed Projects', icon: CheckCircle2, badge: null },
    { id: 'settings', label: 'Settings & Data', icon: Settings, badge: null },
  ];

  return (
    <aside className="w-64 bg-slate-900/95 border-r border-slate-800 flex flex-col justify-between shrink-0 min-h-[calc(100vh-61px)]">
      {/* Navigation List */}
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
          Navigation
        </div>

        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge}
            </button>
          );
        })}
      </div>

      {/* Role & System Status Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span>Active Role:</span>
            <span className="font-semibold text-amber-400">
              {activeRole.type === 'MAIN_ENGINEER' ? 'Main Eng.' : 'Block Eng.'}
            </span>
          </div>
          {activeRole.type === 'BLOCK_ENGINEER' && (
            <p className="text-[11px] text-slate-300">
              Assigned: <span className="font-medium text-white">{activeRole.blockName || 'Block'}</span>
            </p>
          )}
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium pt-1 border-t border-slate-700/50">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>AI Recovery Model Active</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
