import React from 'react';
import { X, ShieldCheck, UserCheck, HardHat, CheckCircle2, Lock } from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { ActiveRole } from '../../types';

interface RoleSwitcherModalProps {
  onClose: () => void;
}

export const RoleSwitcherModal: React.FC<RoleSwitcherModalProps> = ({ onClose }) => {
  const { activeProject, activeRole, switchRole } = useProject();

  const handleSelectRole = (role: ActiveRole) => {
    switchRole(role);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Prototype Role Switcher</h3>
              <p className="text-xs text-slate-400">
                Simulate different site roles for project testing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Roles List */}
        <div className="space-y-3">
          {/* Main Engineer Card */}
          <div
            onClick={() => handleSelectRole({ type: 'MAIN_ENGINEER' })}
            className={`p-4 rounded-xl border cursor-pointer transition-all flex items-start justify-between ${
              activeRole.type === 'MAIN_ENGINEER'
                ? 'bg-amber-500/10 border-amber-500 shadow-lg shadow-amber-500/10'
                : 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600 hover:bg-slate-800'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mt-0.5">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-white text-sm">Main Engineer</h4>
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-500/30">
                    Full Project Access
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Create construction plans, monitor all blocks, trigger AI Recovery, approve reallocations & manage schedule.
                </p>
              </div>
            </div>
            {activeRole.type === 'MAIN_ENGINEER' && (
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-1" />
            )}
          </div>

          <div className="pt-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1 mb-2">
              Block Engineers (Restricted Scope)
            </div>

            {(!activeProject || activeProject.blocks.length === 0) ? (
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 text-center text-xs text-slate-400">
                No blocks created yet. Create a project to assign block engineers.
              </div>
            ) : (
              <div className="space-y-2.5">
                {activeProject.blocks.map(block => {
                  const isSelected =
                    activeRole.type === 'BLOCK_ENGINEER' && activeRole.blockId === block.id;

                  return (
                    <div
                      key={block.id}
                      onClick={() =>
                        handleSelectRole({
                          type: 'BLOCK_ENGINEER',
                          blockId: block.id,
                          engineerName: block.engineerName,
                          blockName: block.name,
                        })
                      }
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-blue-500/10 border-blue-500 shadow-md shadow-blue-500/10'
                          : 'bg-slate-800/60 border-slate-700/80 hover:border-slate-600 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                          <HardHat className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{block.name}</span>
                            <span className="text-xs text-slate-300">({block.engineerName})</span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Scoped only to {block.name} daily data & diary entries
                          </p>
                        </div>
                      </div>
                      {isSelected ? (
                        <CheckCircle2 className="w-5 h-5 text-blue-400" />
                      ) : (
                        <Lock className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
          <span>💡</span>
          <span>
            Block engineers can only view & enter daily data for their assigned block. Switch to Main Engineer to manage global plans.
          </span>
        </div>
      </div>
    </div>
  );
};
