import React, { createContext, useContext, useState, useEffect } from 'react';
import type {
  ActiveRole,
  AIRecoveryAnalysis,
  Block,
  DailyEntry,
  Project,
  Task,
} from '../types';
import {
  getActiveProjectId,
  getProjects,
  getStoredRole,
  resetAllData,
  saveStoredRole,
  saveProjects,
  setActiveProjectId,
} from '../services/storage';
import { calculateProjectOverview } from '../services/deviationEngine';
import { generateRecoveryAnalysis } from '../services/aiRecoveryEngine';

interface ProjectContextType {
  projects: Project[];
  activeProject: Project | null;
  activeRole: ActiveRole;
  setActiveProject: (project: Project | null) => void;
  selectProject: (projectId: string) => void;
  createProject: (
    name: string,
    location: string,
    type: string,
    durationDays: number,
    startDate: string,
    blocksData: Array<{
      name: string;
      engineerName: string;
      initialWorkers: number;
      plannedWorkingHours: number;
    }>
  ) => Project;
  updateProject: (project: Project) => void;
  deleteProject: (projectId: string) => void;
  switchRole: (role: ActiveRole) => void;
  addTaskToBlock: (projectId: string, blockId: string, task: Omit<Task, 'id' | 'status'>) => void;
  updateTask: (projectId: string, blockId: string, task: Task) => void;
  deleteTask: (projectId: string, blockId: string, taskId: string) => void;
  addDailyEntry: (
    projectId: string,
    blockId: string,
    entry: Omit<DailyEntry, 'id' | 'submittedAt'>
  ) => DailyEntry;
  advanceProjectDay: (projectId: string, targetDay?: number) => void;
  triggerAIRecovery: (projectId: string, blockId: string) => AIRecoveryAnalysis | null;
  approveRecovery: (projectId: string, recoveryId: string) => void;
  rejectRecovery: (projectId: string, recoveryId: string) => void;
  resetAll: () => void;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectIdState] = useState<string | null>(null);
  const [activeRole, setActiveRoleState] = useState<ActiveRole>({ type: 'MAIN_ENGINEER' });
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const storedProjects = getProjects();
    const storedActiveId = getActiveProjectId();
    const storedRole = getStoredRole();

    setProjects(storedProjects);
    setActiveRoleState(storedRole);

    if (storedActiveId && storedProjects.some(p => p.id === storedActiveId)) {
      setActiveProjectIdState(storedActiveId);
    } else if (storedProjects.length > 0) {
      setActiveProjectIdState(storedProjects[0].id);
      setActiveProjectId(storedProjects[0].id);
    }
    setInitialized(true);
  }, []);

  const activeProject = projects.find(p => p.id === activeProjectId) || null;

  const persistProjects = (updatedProjects: Project[]) => {
    setProjects(updatedProjects);
    saveProjects(updatedProjects);
  };

  const selectProject = (projectId: string) => {
    setActiveProjectIdState(projectId);
    setActiveProjectId(projectId);
  };

  const setActiveProject = (project: Project | null) => {
    if (project) {
      selectProject(project.id);
    } else {
      setActiveProjectIdState(null);
      setActiveProjectId(null);
    }
  };

  const switchRole = (role: ActiveRole) => {
    setActiveRoleState(role);
    saveStoredRole(role);
  };

  const createProject = (
    name: string,
    location: string,
    type: string,
    durationDays: number,
    startDate: string,
    blocksData: Array<{
      name: string;
      engineerName: string;
      initialWorkers: number;
      plannedWorkingHours: number;
    }>
  ): Project => {
    const newBlocks: Block[] = blocksData.map((b, index) => ({
      id: `block-${String.fromCharCode(97 + index)}-${Date.now()}`,
      name: b.name.trim() || `Block ${String.fromCharCode(65 + index)}`,
      engineerName: b.engineerName.trim() || `Engineer ${String.fromCharCode(65 + index)}`,
      initialWorkers: Number(b.initialWorkers) || 20,
      currentWorkers: Number(b.initialWorkers) || 20,
      plannedWorkingHours: Number(b.plannedWorkingHours) || 7,
      currentWorkingHours: Number(b.plannedWorkingHours) || 7,
      tasks: [],
      dailyEntries: [],
      currentProgress: 0,
    }));

    const newProject: Project = {
      id: 'proj-' + Date.now(),
      name: name.trim() || 'New Construction Project',
      location: location.trim() || 'Site Location',
      type: type || '🏫 Engineering College',
      durationDays: Number(durationDays) || 30,
      startDate: startDate || new Date().toISOString().split('T')[0],
      currentDay: 1,
      status: 'ON_TRACK',
      completedAt: null,
      blocks: newBlocks,
      recoveryLogs: [],
      createdAt: new Date().toISOString(),
    };

    const updated = [newProject, ...projects];
    persistProjects(updated);
    selectProject(newProject.id);
    // Reset to Main Engineer view on new project
    switchRole({ type: 'MAIN_ENGINEER' });
    return newProject;
  };

  const updateProject = (updatedProj: Project) => {
    // Recalculate status & completion
    const overview = calculateProjectOverview(updatedProj);
    const finalizedProj: Project = {
      ...updatedProj,
      status: overview.status,
      completedAt: overview.status === 'COMPLETED' ? (updatedProj.completedAt || new Date().toISOString()) : null,
    };

    const updated = projects.map(p => (p.id === finalizedProj.id ? finalizedProj : p));
    persistProjects(updated);
  };

  const deleteProject = (projectId: string) => {
    const updated = projects.filter(p => p.id !== projectId);
    persistProjects(updated);
    if (activeProjectId === projectId) {
      const nextActive = updated.length > 0 ? updated[0].id : null;
      setActiveProjectIdState(nextActive);
      setActiveProjectId(nextActive);
    }
  };

  const addTaskToBlock = (
    projectId: string,
    blockId: string,
    taskData: Omit<Task, 'id' | 'status'>
  ) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const newTask: Task = {
      ...taskData,
      id: 'task-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      status: 'PENDING',
    };

    const updatedBlocks = proj.blocks.map(block => {
      if (block.id !== blockId) return block;
      return {
        ...block,
        tasks: [...block.tasks, newTask],
      };
    });

    updateProject({ ...proj, blocks: updatedBlocks });
  };

  const updateTask = (projectId: string, blockId: string, updatedTask: Task) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const updatedBlocks = proj.blocks.map(block => {
      if (block.id !== blockId) return block;
      return {
        ...block,
        tasks: block.tasks.map(t => (t.id === updatedTask.id ? updatedTask : t)),
      };
    });

    updateProject({ ...proj, blocks: updatedBlocks });
  };

  const deleteTask = (projectId: string, blockId: string, taskId: string) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const updatedBlocks = proj.blocks.map(block => {
      if (block.id !== blockId) return block;
      return {
        ...block,
        tasks: block.tasks.filter(t => t.id !== taskId),
      };
    });

    updateProject({ ...proj, blocks: updatedBlocks });
  };

  const addDailyEntry = (
    projectId: string,
    blockId: string,
    entryData: Omit<DailyEntry, 'id' | 'submittedAt'>
  ): DailyEntry => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) throw new Error('Project not found');

    const newEntry: DailyEntry = {
      ...entryData,
      id: 'entry-' + Date.now(),
      submittedAt: new Date().toISOString(),
    };

    const updatedBlocks = proj.blocks.map(block => {
      if (block.id !== blockId) return block;

      // Filter out any previous entry for the exact same dayNumber if re-editing/updating
      const filteredEntries = block.dailyEntries.filter(e => e.dayNumber !== entryData.dayNumber);
      const updatedEntries = [...filteredEntries, newEntry].sort((a, b) => a.dayNumber - b.dayNumber);

      // Latest actual progress
      const latestEntry = updatedEntries[updatedEntries.length - 1];
      const newProgress = Math.min(100, Math.max(0, latestEntry ? latestEntry.actualProgress : block.currentProgress));

      // Update task statuses
      const updatedTasks = block.tasks.map(task => {
        if (entryData.dayNumber >= task.endDay && newProgress >= task.expectedProgress) {
          return { ...task, status: 'COMPLETED' as const };
        } else if (entryData.dayNumber >= task.startDay) {
          return { ...task, status: 'IN_PROGRESS' as const };
        }
        return task;
      });

      return {
        ...block,
        dailyEntries: updatedEntries,
        currentProgress: newProgress,
        tasks: updatedTasks,
      };
    });

    // Check if current day should be synced if entry is beyond project currentDay
    const maxDay = Math.max(proj.currentDay, entryData.dayNumber);

    const updatedProj: Project = {
      ...proj,
      currentDay: maxDay,
      blocks: updatedBlocks,
    };

    updateProject(updatedProj);
    return newEntry;
  };

  const advanceProjectDay = (projectId: string, targetDay?: number) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const nextDay = targetDay ?? Math.min(proj.durationDays, proj.currentDay + 1);
    updateProject({
      ...proj,
      currentDay: nextDay,
    });
  };

  const triggerAIRecovery = (projectId: string, blockId: string): AIRecoveryAnalysis | null => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return null;

    const analysis = generateRecoveryAnalysis(proj, blockId);
    if (!analysis) return null;

    const updatedLogs = [analysis, ...(proj.recoveryLogs || [])];
    updateProject({
      ...proj,
      recoveryLogs: updatedLogs,
    });

    return analysis;
  };

  const approveRecovery = (projectId: string, recoveryId: string) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const rec = (proj.recoveryLogs || []).find(r => r.id === recoveryId);
    if (!rec) return;

    // Apply adjustments to target block & donor block (if reallocation exists)
    const updatedBlocks = proj.blocks.map(block => {
      // 1. Target delayed block adjustments
      if (block.id === rec.blockId) {
        let workers = rec.recommendedWorkers;
        return {
          ...block,
          currentWorkers: workers,
          currentWorkingHours: rec.recommendedHours,
        };
      }

      // 2. Donor block adjustment if reallocated
      if (rec.reallocationOpportunity && block.id === rec.reallocationOpportunity.fromBlockId) {
        const remainingWorkers = Math.max(1, (block.currentWorkers || block.initialWorkers) - rec.reallocationOpportunity.workersToReallocate);
        return {
          ...block,
          currentWorkers: remainingWorkers,
        };
      }

      return block;
    });

    const updatedLogs = proj.recoveryLogs.map(r =>
      r.id === recoveryId
        ? { ...r, status: 'APPROVED' as const, approvedAt: new Date().toISOString() }
        : r
    );

    updateProject({
      ...proj,
      blocks: updatedBlocks,
      recoveryLogs: updatedLogs,
    });
  };

  const rejectRecovery = (projectId: string, recoveryId: string) => {
    const proj = projects.find(p => p.id === projectId);
    if (!proj) return;

    const updatedLogs = (proj.recoveryLogs || []).map(r =>
      r.id === recoveryId ? { ...r, status: 'REJECTED' as const } : r
    );

    updateProject({
      ...proj,
      recoveryLogs: updatedLogs,
    });
  };

  const resetAll = () => {
    resetAllData();
    setProjects([]);
    setActiveProjectIdState(null);
    setActiveRoleState({ type: 'MAIN_ENGINEER' });
  };

  if (!initialized) {
    return null;
  }

  return (
    <ProjectContext.Provider
      value={{
        projects,
        activeProject,
        activeRole,
        setActiveProject,
        selectProject,
        createProject,
        updateProject,
        deleteProject,
        switchRole,
        addTaskToBlock,
        updateTask,
        deleteTask,
        addDailyEntry,
        advanceProjectDay,
        triggerAIRecovery,
        approveRecovery,
        rejectRecovery,
        resetAll,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = (): ProjectContextType => {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};
