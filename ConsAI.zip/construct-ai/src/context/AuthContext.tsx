import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { getCurrentUser, getUsers, saveUsers, setCurrentUser } from '../services/storage';

interface AuthContextType {
  user: User | null;
  users: User[];
  login: (email: string, password?: string) => boolean;
  signup: (name: string, email: string, password?: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUserState] = useState<User | null>(null);
  const [users, setUsersState] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = getCurrentUser();
    const storedUsers = getUsers();
    setUserState(savedUser);
    setUsersState(storedUsers);
    setLoading(false);
  }, []);

  const login = (email: string, password?: string): boolean => {
    const storedUsers = getUsers();
    const cleanEmail = email.trim().toLowerCase();
    const existing = storedUsers.find(u => u.email.toLowerCase() === cleanEmail);

    if (existing) {
      if (password && existing.password && existing.password !== password) {
        return false;
      }
      setUserState(existing);
      setCurrentUser(existing);
      return true;
    }

    // For prototype ease, if user logs in without prior signup, create simple profile
    const newUser: User = {
      id: 'usr-' + Date.now(),
      name: email.split('@')[0] || 'Engineer',
      email: cleanEmail,
      password: password || 'demo123',
      createdAt: new Date().toISOString(),
    };
    const updatedUsers = [...storedUsers, newUser];
    saveUsers(updatedUsers);
    setUsersState(updatedUsers);
    setUserState(newUser);
    setCurrentUser(newUser);
    return true;
  };

  const signup = (name: string, email: string, password?: string): boolean => {
    const storedUsers = getUsers();
    const cleanEmail = email.trim().toLowerCase();
    
    if (storedUsers.some(u => u.email.toLowerCase() === cleanEmail)) {
      return false; // Already exists
    }

    const newUser: User = {
      id: 'usr-' + Date.now(),
      name: name.trim() || 'Engineer',
      email: cleanEmail,
      password: password || 'password123',
      createdAt: new Date().toISOString(),
    };

    const updated = [...storedUsers, newUser];
    saveUsers(updated);
    setUsersState(updated);
    setUserState(newUser);
    setCurrentUser(newUser);
    return true;
  };

  const logout = () => {
    setUserState(null);
    setCurrentUser(null);
  };

  if (loading) {
    return null;
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        users,
        login,
        signup,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
