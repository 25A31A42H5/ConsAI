import { Block, DailyEntry, Project, ScheduleDeviation } from '../types';

/**
 * Calculates the planned progress percentage for a block on a given day number
 * based on the tasks planned by the Main Engineer.
 */
export const calculatePlannedProgressForDay = (
  block: Block,
  dayNumber: number,
  totalProjectDuration: number
): number => {
  if (!block.tasks || block.tasks.length === 0) {
    // Linear fallback if no tasks created yet
    return Math.min(100, Math.round((dayNumber / Math.max(1, totalProjectDuration)) * 100));
  }

  // Find maximum expected progress from tasks completed or in progress by dayNumber
  let planned = 0;
  
  // Sort tasks by endDay
  const sortedTasks = [...block.tasks].sort((a, b) => a.startDay - b.startDay);

  for (const task of sortedTasks) {
    if (dayNumber >= task.endDay) {
      planned = Math.max(planned, task.expectedProgress);
    } else if (dayNumber >= task.startDay && dayNumber < task.endDay) {
      // Linear interpolation inside the task
      const taskDuration = Math.max(1, task.endDay - task.startDay);
      const daysElapsedInTask = dayNumber - task.startDay;
      const prevProgress = sortedTasks
        .filter(t => t.endDay <= task.startDay)
        .reduce((max, t) => Math.max(max, t.expectedProgress), 0);
      
      const taskContribution = task.expectedProgress - prevProgress;
      const currentTaskP = prevProgress + (taskContribution * (daysElapsedInTask / taskDuration));
      planned = Math.max(planned, Math.round(currentTaskP));
    }
  }

  // If dayNumber is beyond all tasks, return 100 or max task progress
  const maxTaskEnd = Math.max(...block.tasks.map(t => t.endDay), 1);
  if (dayNumber >= maxTaskEnd) {
    const maxProgress = Math.max(...block.tasks.map(t => t.expectedProgress), 100);
    planned = Math.max(planned, maxProgress);
  }

  return Math.min(100, Math.max(0, Math.round(planned)));
};

/**
 * Analyzes schedule deviation for a specific block on current/target day
 */
export const analyzeBlockDeviation = (
  block: Block,
  project: Project,
  targetDay?: number
): ScheduleDeviation => {
  const currentDay = targetDay ?? project.currentDay;
  const plannedProgress = calculatePlannedProgressForDay(block, currentDay, project.durationDays);
  
  // Find latest entry on or before currentDay
  const entriesOnOrBefore = (block.dailyEntries || [])
    .filter(e => e.dayNumber <= currentDay)
    .sort((a, b) => b.dayNumber - a.dayNumber);
  
  const latestEntry = entriesOnOrBefore[0];
  const actualProgress = latestEntry ? latestEntry.actualProgress : (block.currentProgress || 0);

  const gapPercent = Math.max(0, plannedProgress - actualProgress);
  const remainingDays = Math.max(0, project.durationDays - currentDay);
  
  // Daily planned rate (e.g. 100% / 30 days = 3.33%/day)
  const baseDailyRate = 100 / Math.max(1, project.durationDays);
  
  // Compute estimated delay days:
  // If gap is 15% and daily planned rate is 3.33%, delay = 15 / 3.33 = ~4.5 days
  let estimatedDelayDays = 0;
  if (gapPercent > 0) {
    estimatedDelayDays = Math.round((gapPercent / Math.max(1.0, baseDailyRate)) * 10) / 10;
  }

  let status: ScheduleDeviation['status'] = 'ON_TRACK';
  if (estimatedDelayDays > 3) {
    status = 'SIGNIFICANT_DELAY';
  } else if (estimatedDelayDays >= 2 || gapPercent > 5) {
    status = 'AT_RISK';
  } else {
    status = 'ON_TRACK';
  }

  return {
    gapPercent,
    plannedProgress,
    actualProgress,
    estimatedDelayDays,
    status,
    isSignificant: estimatedDelayDays > 3,
    dailyRate: baseDailyRate,
    remainingDays,
  };
};

/**
 * Calculates overall project progress and status
 */
export const calculateProjectOverview = (project: Project) => {
  if (!project.blocks || project.blocks.length === 0) {
    return {
      overallProgress: 0,
      plannedProgress: 0,
      status: 'ON_TRACK' as const,
      hasSignificantDelay: false,
      delayedBlocksCount: 0,
      atRiskBlocksCount: 0,
      onTrackBlocksCount: 0,
    };
  }

  let totalActual = 0;
  let totalPlanned = 0;
  let delayedBlocksCount = 0;
  let atRiskBlocksCount = 0;
  let onTrackBlocksCount = 0;

  project.blocks.forEach(block => {
    const deviation = analyzeBlockDeviation(block, project);
    totalActual += deviation.actualProgress;
    totalPlanned += deviation.plannedProgress;

    if (deviation.status === 'SIGNIFICANT_DELAY') {
      delayedBlocksCount++;
    } else if (deviation.status === 'AT_RISK') {
      atRiskBlocksCount++;
    } else {
      onTrackBlocksCount++;
    }
  });

  const overallProgress = Math.round(totalActual / project.blocks.length);
  const plannedProgress = Math.round(totalPlanned / project.blocks.length);

  let status: Project['status'] = 'ON_TRACK';
  if (overallProgress >= 100) {
    status = 'COMPLETED';
  } else if (delayedBlocksCount > 0) {
    status = 'DELAYED';
  } else if (atRiskBlocksCount > 0) {
    status = 'AT_RISK';
  }

  return {
    overallProgress,
    plannedProgress,
    status,
    hasSignificantDelay: delayedBlocksCount > 0,
    delayedBlocksCount,
    atRiskBlocksCount,
    onTrackBlocksCount,
  };
};
