import { Project, User, ActiveRole } from '../types';

const STORAGE_KEYS = {
  USERS: 'constructai_users_v1',
  CURRENT_USER: 'constructai_current_user_v1',
  PROJECTS: 'constructai_projects_v1',
  ACTIVE_PROJECT_ID: 'constructai_active_project_id_v1',
  ACTIVE_ROLE: 'constructai_active_role_v1',
};

// Users
export const getUsers = (): User[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error reading users from storage', e);
    return [];
  }
};

export const saveUsers = (users: User[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  } catch (e) {
    console.error('Error saving users to storage', e);
  }
};

export const getCurrentUser = (): User | null => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.error('Error reading current user', e);
    return null;
  }
};

export const setCurrentUser = (user: User | null): void => {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  } catch (e) {
    console.error('Error setting current user', e);
  }
};

// Projects
export const getProjects = (): Project[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    // Starts initially EMPTY! Zero demo/fake projects.
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error reading projects from storage', e);
    return [];
  }
};

export const saveProjects = (projects: Project[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  } catch (e) {
    console.error('Error saving projects to storage', e);
  }
};

export const getActiveProjectId = (): string | null => {
  try {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_PROJECT_ID);
  } catch (e) {
    return null;
  }
};

export const setActiveProjectId = (id: string | null): void => {
  try {
    if (id) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_PROJECT_ID, id);
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_PROJECT_ID);
    }
  } catch (e) {
    console.error('Error setting active project ID', e);
  }
};

// Role simulation
export const getStoredRole = (): ActiveRole => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_ROLE);
    return data ? JSON.parse(data) : { type: 'MAIN_ENGINEER' };
  } catch (e) {
    return { type: 'MAIN_ENGINEER' };
  }
};

export const saveStoredRole = (role: ActiveRole): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_ROLE, JSON.stringify(role));
  } catch (e) {
    console.error('Error saving active role', e);
  }
};

// Reset prototype data (for fresh testing)
export const resetAllData = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEYS.PROJECTS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_PROJECT_ID);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_ROLE);
  } catch (e) {
    console.error('Error resetting data', e);
  }
};
