import { AIRecoveryAnalysis, Block, Project, ReallocationRecommendation } from '../types';
import { analyzeBlockDeviation } from './deviationEngine';

/**
 * Generates an AI-Assisted Recovery Simulation for a delayed block in a project.
 * Analyzes manually entered progress, diary context, logged issues, remaining days,
 * and checks other blocks for workforce reallocation opportunities.
 */
export const generateRecoveryAnalysis = (
  project: Project,
  delayedBlockId: string
): AIRecoveryAnalysis | null => {
  const targetBlock = project.blocks.find(b => b.id === delayedBlockId);
  if (!targetBlock) return null;

  const deviation = analyzeBlockDeviation(targetBlock, project);
  
  // Enforce 3-day deviation rule check (though UI should also guard this)
  const estimatedDelayDays = Math.max(0.1, deviation.estimatedDelayDays);
  const progressGap = Math.max(1, deviation.gapPercent);
  const daysRemaining = Math.max(1, project.durationDays - project.currentDay);
  const remainingWorkPercent = Math.max(1, 100 - deviation.actualProgress);

  const currentWorkers = targetBlock.currentWorkers || targetBlock.initialWorkers || 20;
  const currentHours = targetBlock.currentWorkingHours || targetBlock.plannedWorkingHours || 7;

  // 1. Calculate Recommended Working Hours adjustment
  // Needed extra output ratio to catch up over remaining days
  // E.g., if behind by 15% and 5 days remain, need (15 / 5) = 3% extra progress/day
  const progressDeficitPerRemainingDay = progressGap / daysRemaining;
  const standardDailyProgress = 100 / Math.max(1, project.durationDays);
  const workloadIncreaseRatio = progressDeficitPerRemainingDay / Math.max(1, standardDailyProgress);

  // Reasonable overtime hours (max +2.5 hours/day to prevent worker burnout)
  let extraHours = 0;
  if (workloadIncreaseRatio > 0.1) {
    extraHours = Math.min(2.5, Math.max(0.5, Math.round(workloadIncreaseRatio * 1.5 * 10) / 10));
    // Round to nearest 0.5
    extraHours = Math.round(extraHours * 2) / 2;
  }
  const recommendedHours = Math.round((currentHours + extraHours) * 10) / 10;

  // 2. Calculate Recommended Workforce adjustment
  // Extra workers needed if hours alone don't bridge the gap
  const laborDeficitRatio = (progressGap / 100) * (targetBlock.tasks?.length || 1);
  let extraWorkers = Math.max(1, Math.ceil(currentWorkers * Math.min(0.5, (workloadIncreaseRatio * 0.4))));
  if (estimatedDelayDays > 4) {
    extraWorkers = Math.max(3, Math.min(12, Math.round(currentWorkers * 0.25)));
  }
  const recommendedWorkers = currentWorkers + extraWorkers;

  // 3. Scan other blocks for Workforce Reallocation Opportunities
  let reallocationOpportunity: ReallocationRecommendation | null = null;

  // Find candidate donor blocks that are On Track or Ahead of schedule
  const candidateDonors = project.blocks
    .filter(b => b.id !== targetBlock.id)
    .map(b => {
      const dev = analyzeBlockDeviation(b, project);
      const isAhead = dev.actualProgress >= dev.plannedProgress;
      const bWorkers = b.currentWorkers || b.initialWorkers || 20;
      return {
        block: b,
        deviation: dev,
        isAhead,
        surplusCapacity: isAhead ? Math.floor(bWorkers * 0.2) : 0,
      };
    })
    .sort((a, b) => (b.deviation.actualProgress - b.deviation.plannedProgress) - (a.deviation.actualProgress - a.deviation.plannedProgress));

  if (candidateDonors.length > 0 && (candidateDonors[0].isAhead || candidateDonors[0].surplusCapacity > 0)) {
    const bestDonor = candidateDonors[0];
    const workersToMove = Math.max(1, Math.min(extraWorkers, Math.max(2, bestDonor.surplusCapacity || Math.floor((bestDonor.block.currentWorkers || 20) * 0.15))));

    reallocationOpportunity = {
      fromBlockId: bestDonor.block.id,
      fromBlockName: bestDonor.block.name,
      toBlockId: targetBlock.id,
      toBlockName: targetBlock.name,
      workersToReallocate: workersToMove,
      sourceBlockStatus: bestDonor.deviation.status,
      sourceBlockSurplus: bestDonor.surplusCapacity,
      rationale: `${bestDonor.block.name} is currently ${bestDonor.isAhead ? 'ahead of schedule' : 'operating on-track'} with ${bestDonor.block.currentWorkers || bestDonor.block.initialWorkers} workers. Temporarily reallocating ${workersToMove} workers will balance labor across blocks without risking ${bestDonor.block.name}'s milestone delivery.`,
    };
  }

  // 4. Analyze Diary & Problem logs context
  const recentEntries = (targetBlock.dailyEntries || []).slice(-5);
  const loggedIssues = Array.from(new Set(recentEntries.map(e => e.problems).filter(Boolean))).join(', ');
  const recentDiaries = recentEntries.map(e => e.engineerDiary).filter(Boolean);
  
  let delayDrivers = '';
  if (loggedIssues) {
    delayDrivers = `Identified site constraints from engineer logs: ${loggedIssues}. `;
  }
  if (recentDiaries.length > 0) {
    const sampleDiary = recentDiaries[recentDiaries.length - 1];
    delayDrivers += `Latest engineer diary noted: "${sampleDiary.length > 80 ? sampleDiary.substring(0, 80) + '...' : sampleDiary}". `;
  }

  const aiRationale = `Schedule gap analysis indicates ${targetBlock.name} has fallen ${progressGap}% behind planned milestones (estimated ~${estimatedDelayDays} days delay) with ${daysRemaining} planned days remaining. ${delayDrivers}To recover the baseline schedule within the planned duration, a combined strategy of a +${extraHours} hrs/day shift extension and an addition of ${extraWorkers} workers${reallocationOpportunity ? ` (partially sourced via ${reallocationOpportunity.fromBlockName})` : ''} is simulated to restore target velocity.`;

  const analysis: AIRecoveryAnalysis = {
    id: 'rec-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    projectId: project.id,
    blockId: targetBlock.id,
    blockName: targetBlock.name,
    triggerDay: project.currentDay,
    estimatedDelayDays,
    progressGap,
    currentWorkers,
    recommendedWorkers,
    extraWorkers,
    currentHours,
    recommendedHours,
    extraHours,
    reallocationOpportunity,
    recoveryMilestoneReviewDays: 2, // Standard prototype 2-day checkpoint
    aiRationale,
    status: 'RECOMMENDED',
    createdAt: new Date().toISOString(),
    disclaimer: 'AI Recovery recommendations are prototype simulations generated from manually entered project progress and resource data. They are not guaranteed real-world construction predictions.',
  };

  return analysis;
};
