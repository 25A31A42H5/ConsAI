import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ProjectProvider, useProject } from './context/ProjectContext';
import { AuthScreen } from './components/auth/AuthScreen';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { EmptyDashboard } from './components/dashboard/EmptyDashboard';
import { ActiveDashboard } from './components/dashboard/ActiveDashboard';
import { CreateProjectWizard } from './components/project/CreateProjectWizard';
import { ConstructionPlan } from './components/project/ConstructionPlan';
import { DailyEntryForm } from './components/daily/DailyEntryForm';
import { ProgressMonitoring } from './components/monitoring/ProgressMonitoring';
import { AIRecoveryAssistant } from './components/recovery/AIRecoveryAssistant';
import { ConstructionHistory } from './components/history/ConstructionHistory';
import { CompletedProjects } from './components/history/CompletedProjects';
import { ActiveProjectsList } from './components/project/ActiveProjectsList';
import { SettingsView } from './components/settings/SettingsView';
import { TestGuideModal } from './components/guide/TestGuideModal';

const MainAppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const { projects, activeProject, selectProject } = useProject();

  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [selectedBlockForAction, setSelectedBlockForAction] = useState<string | undefined>();
  const [showGuideModal, setShowGuideModal] = useState<boolean>(false);

  // Trigger celebration confetti when project hits 100%
  useEffect(() => {
    if (activeProject && activeProject.status === 'COMPLETED') {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#10b981', '#3b82f6', '#ec4899'],
        });
      } catch (e) {
        // Safe fallback
      }
    }
  }, [activeProject?.status]);

  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  const handleOpenAIRecovery = (blockId?: string) => {
    setSelectedBlockForAction(blockId);
    setCurrentView('ai_recovery');
  };

  const handleOpenDailyEntry = (blockId?: string) => {
    setSelectedBlockForAction(blockId);
    setCurrentView('daily_entry');
  };

  const handleOpenProjectFromList = (projectId: string) => {
    selectProject(projectId);
    setCurrentView('dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500 selection:text-slate-950">
      {/* Top Navigation Bar */}
      <Navbar onNavigate={setCurrentView} />

      {/* Main Layout Container with Sidebar and Content View */}
      <div className="flex-1 flex flex-col md:flex-row">
        <Sidebar currentView={currentView} onNavigate={setCurrentView} />

        <main className="flex-1 overflow-x-hidden flex flex-col">
          {/* 1. Dashboard View */}
          {currentView === 'dashboard' && (
            projects.length === 0 ? (
              <EmptyDashboard onCreateProject={() => setCurrentView('create_project')} />
            ) : (
              <ActiveDashboard
                onNavigate={setCurrentView}
                onOpenAIRecovery={handleOpenAIRecovery}
                onOpenDailyEntry={handleOpenDailyEntry}
              />
            )
          )}

          {/* 2. Active Projects View */}
          {currentView === 'active_projects' && (
            <ActiveProjectsList
              onOpenProject={handleOpenProjectFromList}
              onCreateNew={() => setCurrentView('create_project')}
            />
          )}

          {/* 3. Create Project Wizard */}
          {currentView === 'create_project' && (
            <CreateProjectWizard
              onSuccess={() => setCurrentView('dashboard')}
              onCancel={() => setCurrentView('dashboard')}
            />
          )}

          {/* 4. Construction Plan Roadmap */}
          {currentView === 'plans' && (
            <ConstructionPlan />
          )}

          {/* 5. Daily Entry & Diary Form */}
          {currentView === 'daily_entry' && (
            <DailyEntryForm
              initialBlockId={selectedBlockForAction}
              onEntrySubmitted={() => {
                // Stay on summary or navigate to dashboard if desired
              }}
            />
          )}

          {/* 6. Live Monitoring & Deviation */}
          {currentView === 'monitoring' && (
            <ProgressMonitoring onOpenAIRecovery={handleOpenAIRecovery} />
          )}

          {/* 7. Daily Diaries & History */}
          {currentView === 'diaries' && (
            <ConstructionHistory />
          )}

          {/* 8. AI Recovery Assistant */}
          {currentView === 'ai_recovery' && (
            <AIRecoveryAssistant
              initialBlockId={selectedBlockForAction}
              onClose={() => setCurrentView('dashboard')}
            />
          )}

          {/* 9. Completed Projects Archive */}
          {currentView === 'completed' && (
            <CompletedProjects onOpenProject={handleOpenProjectFromList} />
          )}

          {/* 10. Settings & Reset Data */}
          {currentView === 'settings' && (
            <SettingsView onOpenGuide={() => setShowGuideModal(true)} />
          )}
        </main>
      </div>

      {/* Guide Modal if opened via settings or button */}
      {showGuideModal && <TestGuideModal onClose={() => setShowGuideModal(false)} />}
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <ProjectProvider>
        <MainAppContent />
      </ProjectProvider>
    </AuthProvider>
  );
};

export default App;
